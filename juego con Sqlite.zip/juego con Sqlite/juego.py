# -*- coding: utf-8 -*-
import sqlite3
from random import randint
import os
print "\n"
print u"Bienvenido al Juego de Piedra, Papel o Tijera"
print u"Elaborado por: CAMILO ANDRÉS LÓPEZ SARMIENTO\n"
print u"Reglas del juego: "
print u"1. Elige una opción entre Piedra, Papel y Tijera."
print u"2. La Piedra le gana a la Tijera.\n  -El Papel le gana a la Piedra.\n  -La Tijera le gana al Papel."
print u"3. Si los dos eligen la misma opción es un empate."
print u"4. Espera que la máquina o el segundo jugador elija una opción."
print u"5. Mira el ganador y tus puntos obtenidos."
print u"6. El que tengas más puntos al final del juego GANA"
print u"7. Disfruta del juego.\n"
ptsp=0
ptsm=0
empate=0
ptsp1=0
ptsp2=0
empatevs=0

def crear_Tabla ( ):

	con=sqlite3.connect("Puntajes")
	cursor = con.cursor()

	print u"\nLa base de datos se abrio correctamente"

	cursor.execute('''CREATE TABLE PUNTAJES
		(ID INTEGER PRIMARY KEY  AUTOINCREMENT,
		JUGADOR TEXT  NOT NULL,
		PARTIDAS_G     INT,
		PARTIDAS_P     INT,
		PARTIDAS_E     INT)''')

	print u"Tabla creada con éxito\n"
	con.close()

def nuevo_Jugador ():
	global ptsp
	global ptsm
	global empate
	os.system("cls")
	con=sqlite3.connect("Puntajes")
	cursor = con.cursor()
	print u"\nLa base de datos se abrió correctamente\n "
	while True:
		print u"Digite su nombre de perfil sin espacios ni caracteres especiales como lo son las tildes ejemplo: (Ó, Ü, á, é, í, ú, ü), tampoco puede usar signos de puntuacion como lo son: ( . , : _ - ; ...)\n"
		jug=raw_input(" ")
		
		cursor.execute('''INSERT INTO PUNTAJES ( JUGADOR, PARTIDAS_G, PARTIDAS_P, PARTIDAS_E) \
	                   VALUES ('%s', '%s', '%s', '%s')'''%(jug, ptsp, ptsm, empate))	

		cursor.execute("select ID from puntajes where JUGADOR='%s'"%(jug))
		for i in cursor:
			print u"\nEste va a ser su NÚMERO DE PERFIL, guardelo, conservelo o memorícelo\npara utilizarlo cuando desee cargar su partida, gracias\n"
			print u"Número de PERFIL: %d"%(i[0])
		print u"Nombre de PERFIL: %s"%(jug)

		con.commit()
		con.cursor()
		ptsp=0
		ptsm=0
		empate=0
		print u"\nPERFIL guardado correctamente...\n"
		os.system("pause")
		os.system("cls")
		break

		

def cargar_Perfil ():
	os.system("cls")
	global ptsp
	global ptsm
	global empate
	print u"\nCúal de las siguienes opciones conoce para cargar su PERFIL\n"
	print u" 1. Número de PERFIL\n 2. Nombre de PERFIL\n"
	op4=input("Eliga una opcion: ")
	if op4==1:
		con=sqlite3.connect("Puntajes")
		cursor = con.cursor()
		print u"\nLa base de datos se abrió correctamente\n "
		num=input(" Digite su Numero de PERFIL: ")
		usuario=cursor.execute("select * from Puntajes where ID="+str(num))
		existe=False
		for i in usuario:
			existe=True

		if existe==False:
			print u"\nUsted no se encuentra registrado, por favor REGISTRESE y..."
			print u"\nDigite su nombre de perfil sin espacios ni caracteres especiales como lo son las tildes ejemplo: (Ó, Ü, á, é, í, ú, ü), tampoco puede usar signos de puntuacion como lo son: ( . , : _ - ; ...)\n"
			jug1=raw_input(" ")
			
			cursor.execute('''INSERT INTO PUNTAJES ( JUGADOR, PARTIDAS_G, PARTIDAS_P, PARTIDAS_E) \
		                   VALUES ('%s', '%s', '%s', '%s')'''%(jug1, ptsp, ptsm, empate))	

			cursor.execute("select ID from puntajes where JUGADOR='%s'"%(jug1))
			for i in cursor:
				print u"\nEste va a ser su NÚMERO DE PERFIL, guardelo, conservelo o memorícelo\npara utilizarlo cuando desee cargar su partida, gracias\n"
				print u"Número de PERFIL: %d"%(i[0])
			print u"Nombre de PERFIL: %s"%(jug1)

			cursor.execute("select ID, JUGADOR, PARTIDAS_P, PARTIDAS_G, PARTIDAS_E from puntajes where JUGADOR='%s'"%(jug1))

			for i in cursor:
				ptsp=i[2]
				ptsm=i[3]
				empate=i[4]
				print u"\nID ="+str(i[0])+u"       JUGADOR: "+str(i[1])+"\n"
				print u"GANADAS = %s"%(i[3])+u" | PERDIDAS= %s"%(i[2])+u" | EMPATADAS = %s"%(i[4])
					
			con.commit()


		else:	
			cursor.execute("select ID, JUGADOR, PARTIDAS_P, PARTIDAS_G, PARTIDAS_E from puntajes where ID="+str(num))

			for i in cursor:
				ptsp=i[2]
				ptsm=i[3]
				empate=i[4]
				print u"\nID ="+str(i[0])+u"       JUGADOR: "+str(i[1])+"\n"
				print u"GANADAS = %s"%(i[3])+u" | PERDIDAS = %s"%(i[2])+u" | EMPATADAS = %s"%(i[4])
					
			con.commit()

		print u"\nSu PERFIL se cargo correctamente"
		con.close()
		os.system("pause")
		os.system("cls")

	elif op4==2:
		con=sqlite3.connect("Puntajes")
		cursor = con.cursor()
		print u"\nLa base de datos se abrió correctamente\n "
		per=raw_input(" Digite su Nombre de PERFIL: ")
		usuario2=cursor.execute("select * from Puntajes where JUGADOR='%s'"%(per))
		existe=False
		for i in usuario2:
			existe=True

		if existe==False:
			print u"\nUsted no se encuentra registrado, por favor REGISTRESE y..."
			print u"\nDigite su nombre de perfil sin espacios ni caracteres especiales como lo son las tildes ejemplo: (Ó, Ü, á, é, í, ú, ü), tampoco puede usar signos de puntuacion como lo son: ( . , : _ - ; ...)\n"
			jug2=raw_input(" ")
			
			cursor.execute('''INSERT INTO PUNTAJES ( JUGADOR, PARTIDAS_G, PARTIDAS_P, PARTIDAS_E) \
		                   VALUES ('%s', '%s', '%s', '%s')'''%(jug2, ptsp, ptsm, empate))	

			cursor.execute("select ID from puntajes where JUGADOR='%s'"%(jug2))
			for i in cursor:
				print u"\nEste va a ser su NÚMERO DE PERFIL, guardelo, conservelo o memorícelo\npara utilizarlo cuando desee cargar su partida, gracias\n"
				print u"Número de PERFIL: %d"%(i[0])
			print u"Nombre de PERFIL: %s"%(jug2)

			cursor.execute("select ID, JUGADOR, PARTIDAS_P, PARTIDAS_G, PARTIDAS_E from puntajes where JUGADOR='%s'"%(jug2))

			for i in cursor:
				ptsp=i[2]
				ptsm=i[3]
				empate=i[4]
				print u"\nID ="+str(i[0])+u"       JUGADOR: "+str(i[1])+"\n"
				print u" GANADAS = %s"%(i[3])+u" | PERDIDAS = %s"%(i[2])+u" | EMPATADAS = %s"%(i[4])
					
			con.commit()

		else:	
			cursor.execute("select ID, JUGADOR, PARTIDAS_P, PARTIDAS_G, PARTIDAS_E from Puntajes where JUGADOR='%s'"%(per))
			
			for i in cursor:
				ptsp=i[2]
				ptsm=i[3]
				empate=i[4]
				print u"\nID = %s"%(i[0])+u"       JUGADOR: %s"%(i[1])+"\n"
				print u"GANADAS = %s"%(i[3])+u" | PERDIDAS = %s"%(i[2])+u" | EMPATADAS = %s"%(i[4])
				
			con.commit()

		print u"\nSu PERFIL se cargo correctamente"
		con.close()
		os.system("pause")
		os.system("cls")
		
	else:
		print u" \nNo es una opción, su partida No se guardo"
		os.system("pause")
		
def guardar ():
	global ptsp
	global ptsm
	global empate
	print u"\n Para guardar su perfil eliga una opción e ingrese el dato correspondiente"
	print u"\n1. Guardar con Número de PERFIL\n2. Guardar con Nombre de Perfil "
	op3=input(" ")
	if op3==1:		
		con=sqlite3.connect("Puntajes")
		cursor = con.cursor()
		print u"\nLa base de datos se abrió correctamente\n "
		guardar=input(" Digite su Numero de PERFIL: ")
		usuario=cursor.execute("select * from Puntajes where ID="+str(guardar))
		existe=False		
		for i in usuario:
			existe=True

		if existe==False:
			print u"\nUsted no se encuentra registrado, por favor REGISTRESE y..."
			print u"\nDigite su nombre de perfil sin espacios ni caracteres especiales como lo son las tildes ejemplo: (Ó, Ü, á, é, í, ú, ü), tampoco puede usar signos de puntuacion como lo son: ( . , : _ - ; ...)\n"
			jug3=raw_input(" ")
			
			cursor.execute('''INSERT INTO PUNTAJES ( JUGADOR, PARTIDAS_G, PARTIDAS_P, PARTIDAS_E) \
		                   VALUES ('%s', '%s', '%s', '%s')'''%(jug3, ptsp, ptsm, empate))	

			cursor.execute("select ID from puntajes where JUGADOR='%s'"%(jug3))
			for i in cursor:
				print u"\nEste va a ser su NÚMERO DE PERFIL, guardelo, conservelo o memorícelo\npara utilizarlo cuando desee cargar su partida, gracias\n"
				print u"Número de PERFIL: %d"%(i[0])
			print u"Nombre de PERFIL: %s"%(jug3)

			cursor.execute("UPDATE PUNTAJES SET PARTIDAS_G="+str(ptsp)+", PARTIDAS_P="+str(ptsm)+", PARTIDAS_E="+str(empate)+" WHERE JUGADOR='%s'"%(jug3))
			con.commit()						
		else:
			cursor.execute("UPDATE PUNTAJES SET PARTIDAS_G="+str(ptsp)+", PARTIDAS_P="+str(ptsm)+", PARTIDAS_E="+str(empate)+" WHERE ID="+str(guardar))
			con.commit()
		print u"\nSe guardo correctamente"
		con.close()
		os.system("pause")
		os.system("cls")
	elif op3==2:		
		con=sqlite3.connect("Puntajes")
		cursor = con.cursor()
		print u"\nLa base de datos se abrió correctamente\n "
		guardar1=raw_input(" Digite su Nombre de PERFIL: ")
		usuario2=cursor.execute("select * from Puntajes where JUGADOR='%s'"%(guardar1))
		existe=False		
		for i in usuario2:
			existe=True

		if existe==False:
			print u"\nUsted no se encuentra registrado, por favor REGISTRESE y..."
			print u"\nDigite su nombre de perfil sin espacios ni caracteres especiales como lo son las tildes ejemplo: (Ó, Ü, á, é, í, ú, ü), tampoco puede usar signos de puntuacion como lo son: ( . , : _ - ; ...)\n"
			jug4=raw_input(" ")
			
			cursor.execute('''INSERT INTO PUNTAJES ( JUGADOR, PARTIDAS_G, PARTIDAS_P, PARTIDAS_E) \
		                   VALUES ('%s', '%s', '%s', '%s')'''%(jug4, ptsp, ptsm, empate))	

			cursor.execute("select ID from Puntajes where JUGADOR='%s'"%(jug4))
			for i in cursor:
				print u"\nEste va a ser su NÚMERO DE PERFIL, guardelo, conservelo o memorícelo\npara utilizarlo cuando desee cargar su partida, gracias\n"
				print u"Número de PERFIL: %d"%(i[0])
			print u"Nombre de PERFIL: %s"%(jug4)
			cursor.execute("UPDATE PUNTAJES SET PARTIDAS_G="+str(ptsp)+", PARTIDAS_P="+str(ptsm)+", PARTIDAS_E="+str(empate)+" WHERE JUGADOR='%s'"%(jug4))
			con.commit()
		else:
			cursor.execute("UPDATE PUNTAJES SET PARTIDAS_G="+str(ptsp)+", PARTIDAS_P="+str(ptsm)+", PARTIDAS_E="+str(empate)+" WHERE JUGADOR='%s'"%(guardar1))
			con.commit()
		print u"\nSe guardo correctamente"
		con.close()
		os.system("pause")
		os.system("cls")
	else:
		print u" No es una opción, su partida No se guardo"

def guardarjj(pe2,pj1,pj2):
	archivo3=open("pe2.txt","w")
	archivo4=open("pj1.txt","w")
	archivo5=open("pj2.txt","w")
	contenido3=archivo3.write(pe2)
	contenido4=archivo4.write(pj1)
	contenido5=archivo5.write(pj2)
	archivo3.close()
	archivo4.close()
	archivo5.close()

def cargarjj():
	global empatevs
	global ptsp1
	global ptsp2
	archivo3=open("pe2.txt","r")
	archivo4=open("pj1.txt","r")
	archivo5=open("pj2.txt","r")
	contenido3=archivo3.read()
	contenido4=archivo4.read()
	contenido5=archivo5.read()
	archivo3.close()
	archivo4.close()
	archivo5.close()
	empatevs=int(contenido3)
	ptsp1=int(contenido4)
	ptsp2=int(contenido5)
    
def Piedra(player,pc):
	global ptsp
	global ptsm
	global empate
	if pc==1:		
		print u"\n..... ES UN EMPATE ......\n"+u"Máquina saco Piedra"
		print u"intentalo de nuevo\n"	
		empate+=1
		os.system("pause")
	elif pc==2:
		print u"\n..... PERDISTE :( .....\n"+u"Máquina saco Papel"
		print u"vuelve a intentarlo\n"	
		ptsm+=1	
		os.system("pause")
	elif pc==3:
		print u"..!!!!!! GANASTEEEEE !!!!!.."+u"Máquina saco Tijera"
		print u"felicitaciones\n"
		ptsp+=1	
		os.system("pause")
def Papel(player,pc):
	global ptsm
	global ptsp
	global empate
	if pc==1:
		print u"..!!!!!! FELICITACIÓNES GANASTEEEEE !!!!!.."+u"Máquina saco Piedra"
		print u"felicitaciones\n"
		ptsp+=1
		os.system("pause")
	elif pc==2:
		print u"\n..... ES UN EMPATE ......\n"+u"Máquina saco Papel"
		print u"intentalo de nuevo\n"	
		empate+=1	
		os.system("pause")
	elif pc==3:
		print u"\n..... PERDISTE :( .....\n"+u"Máquina saco Tijera"
		print u"vuelve a intentarlo\n"
		ptsm+=1
		os.system("pause")
def Tijera(player,pc):
	global ptsp
	global ptsm
	global empate
	if pc==1:
		print u"\n..... PERDISTE :( .....\n"+u"Máquina saco Piedra"
		print u"vuelve a intentarlo\n "
		ptsm+=1
		os.system("pause")
	elif pc==2:
		print u"..!!!!!! GANASTEEEEE XD !!!!!.."+u"Máquina saco Papel"
		print u"felicitaciones\n"
		ptsp+=1
		os.system("pause")
	elif pc==3:
		print u"\n..... ES UN EMPATE ......\n"+u"Máquina saco Tijera"
		print u"intentalo de nuevo\n"
		empate+=1
		os.system("pause")

while True:
	print u"\n1. Crear Tabla de datos\n2. Continuar con el juego (Eliga esta)\n3. Salir\n"
	op6=input("Eliga una opcion: ")
	os.system("cls")
	if op6==1:
		crear_Tabla()
	if op6==2:		
		print u"\n1. Nuevo Jugador\n2. Cargar PERFIL\n"
		op5=input("Eliga una opcion: ")
		os.system("cls")
		if op5==1:
			nuevo_Jugador()
			print u"\n1. Nuevo Juego\n2. Salir\n "
			op=input("Eliga una opcion: ")
			os.system("cls")
			if op==1:
				print u"\nOpciones de juego:\n 1. Contra la máquina\n 2. Contra un amigo\n "
				opcion=input(" ")
				print"\n"
				if opcion==1:
					empate=0
					ptsp=0
					ptsm=0
								
					while True:
						os.system("cls")
						print u"PUNTOS --------->  Empatados: "+str(empate)+u" | Jugador : "+str(ptsp)+u" | Máquina: "+str(ptsm)
						print u"\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
						player=input(" ")
						if player==1:
							print u"\nEliges Piedra"
							pc=randint(1, 3)
							Piedra(player,pc)
						elif player==2:
							print u"\nEliges Papel"
							pc=randint(1, 3)
							Papel(player,pc)
						elif player==3:
							print u"\nEliges Tijera"
							pc=randint(1, 3)
							Tijera(player,pc)
						elif player==4:
							print u"\n1. Guardar\n2. Guardar y Salir\n3. Salir\n"	
							op1=input(" ")
							if op1==1:
								guardar()
								os.system("cls")
							elif op1==2:
								guardar()
								os.system("cls")
								break
							elif op1==3:
								os.system("cls")
								break
							else:
								print u"No es una opción, elige de nuevo"
					  	else:
					    	 print u"No es una opción, elige de nuevo"
				elif opcion==2:
					empatevs=0
					ptsp1=0
					ptsp2=0
					guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
					while True:
						os.system("cls")
						print u"PUNTOS --------->  Empatados: "+str(empatevs)+" | Jugador 1: "+str(ptsp1)+" | Jugador 2: "+str(ptsp2)			
						print u"\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
						player1=input("Jugador1: ")
						os.system("cls")
						print u"PUNTOS --------->  Empatados: "+str(empatevs)+" | Jugador 1: "+str(ptsp1)+" | Jugador 2: "+str(ptsp2)			
						print u"\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
						player2=input("Jugador2: ")
						jugadas=["Piedra","Papel","Tijera"]
						if player1==1 and player2==1:	
							print u"\n......  ES UN EMPATE ......\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]							
							empatevs+=1
							os.system("pause")
						elif player1==1 and player2==2:
							print u"\n.... GANA JUGADOR 2 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp2+=1
							os.system("pause")
						elif player1==1 and player2==3:
							print u"\n.... GANA JUGADOR 1 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp1+=1
							os.system("pause")
						elif player1==2 and player2==1:
							print u"\n.... GANA JUGADOR 1 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp1+=1
							os.system("pause")
						elif player1==2 and player2==2:
							print u"\n......  ES UN EMPATE ......\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							empatevs+=1
							os.system("pause")
						elif player1==2 and player2==3:
							print u"\n.... GANA JUGADOR 2 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp2+=1
							os.system("pause")
						elif player1==3 and player2==1:
							u"\n.... GANA JUGADOR 2 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp2+=1
							os.system("pause")
						elif player1==3 and player2==2:
							print u"\n.... GANA JUGADOR 1 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp1+=1
							os.system("pause")
						elif player1==3 and player2==3:
							print u"\n......  ES UN EMPATE ......\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							empatevs+=1
							os.system("pause")
						elif player1==4:
							print u"\n1. Guardar\n2. Guardar y Salir\n3. Salir\n "	
							op1=input(" ")
							if op1==1:
								guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
								os.system("cls")
							elif op1==2:
								guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
								os.system("cls")
								break
							elif op1==3:
								os.system("cls")
								break
							else:
								print u"No es una opción, elige de nuevo"
					  	else:
					    	 print u"No es una opción, elige de nuevo"
			elif op==2:		
				break
			else:
				print u"No es una opción, elige denuevo\n"
		elif op5==2:
			cargar_Perfil()
			print u"\n1. Nuevo Juego\n2. Cargar Partida\n3. Salir\n "
			op=input("Eliga una opcion: ")
			if op==1:
				print u"\nOpciones de juego:\n 1. Contra la máquina\n 2. Contra un amigo\n "
				opcion=input(" ")
				print"\n"
				if opcion==1:
					empate=0
					ptsp=0
					ptsm=0
								
					while True:
						os.system("cls")
						print "PUNTOS --------->  Empatados: "+str(empate)+" | Jugador : "+str(ptsp)+" | Máquina: "+str(ptsm)
						print u"\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
						player=input(" ")
						if player==1:
							print u"\nEliges Piedra"
							pc=randint(1, 3)
							Piedra(player,pc)
						elif player==2:
							print u"\nEliges Papel"
							pc=randint(1, 3)
							Papel(player,pc)
						elif player==3:
							print u"\nEliges Tijera"
							pc=randint(1, 3)
							Tijera(player,pc)
						elif player==4:
							print u"\n1. Guardar\n2. Guardar y Salir\n3. Salir\n"	
							op1=input(" ")
							if op1==1:
								guardar()
								os.system("cls")
							elif op1==2:
								guardar()
								os.system("cls")
								break
							elif op1==3:
								os.system("cls")
								break
							else:
								print u"No es una opción, elige de nuevo"
					  	else:
					    	 print u"No es una opción, elige de nuevo"
				elif opcion==2:
					empatevs=0
					ptsp1=0
					ptsp2=0
					guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
					while True:
						os.system("cls")
						print u"PUNTOS --------->  Empatados: "+str(empatevs)+" | Jugador 1: "+str(ptsp1)+" | Jugador 2: "+str(ptsp2)			
						print u"\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
						player1=input("Jugador1: ")
						os.system("cls")
						print u"PUNTOS --------->  Empatados: "+str(empatevs)+" | Jugador 1: "+str(ptsp1)+" | Jugador 2: "+str(ptsp2)			
						print u"\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
						player2=input("Jugador2: ")
						jugadas=["Piedra","Papel","Tijera"]
						if player1==1 and player2==1:	
							print u"\n......  ES UN EMPATE ......\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							empatevs+=1
							os.system("pause")
						elif player1==1 and player2==2:
							u"\n.... GANA JUGADOR 2 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp2+=1
							os.system("pause")
						elif player1==1 and player2==3:
							print u"\n.... GANA JUGADOR 1 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp1+=1
							os.system("pause")
						elif player1==2 and player2==1:
							print u"\n.... GANA JUGADOR 1 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp1+=1
							os.system("pause")
						elif player1==2 and player2==2:
							print u"\n......  ES UN EMPATE ......\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							empatevs+=1
							os.system("pause")
						elif player1==2 and player2==3:
							print u"\n.... GANA JUGADOR 2 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp2+=1
							os.system("pause")
						elif player1==3 and player2==1:
							print u"\n.... GANA JUGADOR 2 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp2+=1
							os.system("pause")
						elif player1==3 and player2==2:
							print u"\n.... GANA JUGADOR 1 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp1+=1
							os.system("pause")
						elif player1==3 and player2==3:
							print u"\n......  ES UN EMPATE ......\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							empatevs+=1
							os.system("pause")
						elif player1==4:
							print u"\n1. Guardar\n2. Guardar y Salir\n3. Salir\n "	
							op1=input(" ")
							if op1==1:
								guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
								os.system("cls")
							elif op1==2:
								guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
								os.system("cls")
								break
							elif op1==3:
								os.system("cls")
								break
							else:
								print u"No es una opción, elige de nuevo"
					  	else:
					    	 print u"No es una opción, elige de nuevo"
			elif op==2:
				print u"Opciones de juego:\n 1. Contra la máquina\n 2. Contra un amigo\n "
				opcion=input()
				if opcion==1:
					while True:
						os.system("cls")
						print u"PUNTOS --------->  Empatados: "+str(empate)+u" | Máquina: "+str(ptsm)+u" | Jugador: "+str(ptsp)
						print u"\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
						player=input(" ")
						if player==1:
							print "\nEliges Piedra"
							pc=randint(1, 3)
							Piedra(player,pc)
						elif player==2:
							print u"\nEliges Papel"
							pc=randint(1, 3)
							Papel(player,pc)
						elif player==3:
							print u"\nEliges Tijera"
							pc=randint(1, 3)
							Tijera(player,pc)
						elif player==4:
							print u"\n1. Guardar\n2. Guardar y Salir\n3. Salir\n"	
							op1=input(" ")
							if op1==1:
								guardar()
								os.system("cls")
							elif op1==2:
								guardar()
								os.system("cls")
								break
							elif op1==3:
								os.system("cls")
								break
							else:
								print u"No es una opción, elige de nuevo"
					  	else:
					    	 print u"No es una opción, elige de nuevo"
				elif opcion==2:
					cargarjj()
					while True:
						os.system("cls")
						print u"PUNTOS --------->  Empatados: "+str(empatevs)+" | Jugador 1: "+str(ptsp1)+" | Jugador 2: "+str(ptsp2)			
						print u"\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
						player1=input("Jugador1: ")
						os.system("cls")
						print u"PUNTOS --------->  Empatados: "+str(empatevs)+" | Jugador 1: "+str(ptsp1)+" | Jugador 2: "+str(ptsp2)			
						print u"\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
						player2=input("Jugador2: ")
						jugadas=["Piedra","Papel","Tijera"]
						if player1==1 and player2==1:	
							print u"\n......  ES UN EMPATE ......\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							empatevs+=1
							os.system("pause")
						elif player1==1 and player2==2:
							print u"\n.... GANA JUGADOR 2 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp2+=1
							os.system("pause")
						elif player1==1 and player2==3:
							print u"\n.... GANA JUGADOR 1 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp1+=1
							os.system("pause")
						elif player1==2 and player2==1:
							print u"\n.... GANA JUGADOR 1 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp1+=1
							os.system("pause")
						elif player1==2 and player2==2:
							print u"\n......  ES UN EMPATE ......\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							empatevs+=1
							os.system("pause")
						elif player1==2 and player2==3:
							print u"\n.... GANA JUGADOR 2 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp2+=1
							os.system("pause")
						elif player1==3 and player2==1:
							print u"\n.... GANA JUGADOR 2 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp2+=1
							os.system("pause")
						elif player1==3 and player2==2:
							print u"\n.... GANA JUGADOR 1 .....\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							ptsp1+=1
							os.system("pause")
						elif player1==3 and player2==3:
							print u"\n......  ES UN EMPATE ......\n"
							print u"Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
							empatevs+=1
							os.system("pause")
						elif player1==4:
							print u"\n1. Guardar\n2. Guardar y Salir\n3. Salir\n "	
							op1=input(" ")
							if op1==1:
								guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
								os.system("cls")
							elif op1==2:
								guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
								os.system("cls")
								break
							elif op1==3:
								os.system("cls")
								break
							else:
								print u"No es una opción, elige de nuevo"
					  	else:
					    	 print u"No es una opción, elige de nuevo"
			elif op==3:
				break
			else:
				print u"No es una opción, elige denuevo\n"
	elif op6==3:
		break
	else:
		print u"No es una opción, elige denuevo\n"

