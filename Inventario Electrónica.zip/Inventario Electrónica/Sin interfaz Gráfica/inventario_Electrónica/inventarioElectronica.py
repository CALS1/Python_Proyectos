
# -*- coding: utf-8 -*-
""" Aqui se importan librerias para ser utilizadas en los metodos y clases"""

import sqlite3
import os

"""CREAR LA TABLA EN LA QUE ESTARAN LISTADOS TODOS LOS ELEMENTOS, esto solo se hara una unica vez durante la utilizacion
del programa, si la tabla ya se encuentra creada, no hay nececidad de ejecutar esta funcion"""

def crear_Tabla ( ):

		con=sqlite3.connect("inventarioElectronica")
		cursor = con.cursor()

		print u"\nLa base de datos se abrio correctamente"

		cursor.execute('''CREATE TABLE INVENTARIO_ELECTRONICA
			(ID INTEGER PRIMARY KEY  AUTOINCREMENT,
			ELEMENTO TEXT  NOT NULL,
			IMAGEN     TEXT,
			CARACTERISTICA     TEXT,
			DESCRIPCION    TEXT,
			UBICACION   TEXT)''')

		print u"\n Tabla creada con éxito\n"
		con.close()
		print " Ya puede continuar utilizando las demas funciones del programa, gracias\n"
		os.system("pause")
		
"""Clase en la cual se va hacer la definicion de parametros en donde se haran las respectivas conexiones a la base de datos desde agregar el elemento hasta listar,
editar y borrar el elemento o caracteristica de este"""


		
""" Clase en la cual se va hacer la definicion de parametros en donde se va a crear el elemento"""
class elemento():
	"""Metodo constructor de un elemento nuevo, todos los elementos creados van a tener los atributos 
	asiganados en esta funcion(metodo)  """

	def __init__(self,nombre,imagen,caracteristica,descripcion,ubicacion):

		self.nombre=nombre
		self.imagen=imagen
		self.caracteristica=caracteristica
		self.descripcion=descripcion
		self.ubicacion=ubicacion

	"""Este metodo va a permitir agregar o insertar los elementos creados a la base de datos(tabla)"""
	def agregarElemento (self):
			os.system("cls")
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\n La base de datos se abrió correctamente\n "
			cursor.execute('''INSERT INTO INVENTARIO_ELECTRONICA ( ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION) \
		                   VALUES ('%s', '%s', '%s', '%s', '%s')'''%(componente.nombre, componente.imagen, componente.caracteristica, componente.descripcion, componente.ubicacion))	
			con.commit()
			con.cursor()
			print u" Elemento guardado correctamente...\n"
			os.system("pause")
			os.system("cls")

"""NOTA: Todos los metodos creados a continuacion van a ser creados fuera de la clase "elemento", esto para un mejor
funcionamiento del programa y por problemas durante la buena funcion de cada metodo. """


"""Este metodo va a permitir editar o modificar los elementos creados a la base de datos, ya sea nombre,
 descripcion, caracteristica, imagen o ubicacion en la base de datos(tabla)"""
def editarElemento ():
	os.system("cls")
	while True:
		print "\n 1. Mostrar Todos los elementos del inventario\n\n 2. Mostrar un elemento en especifico\n\n 3. Salir\n"
		opcion1=input(" Elija una opcion: ")
		os.system("cls")

		if opcion1==1:
			"""Esta opcion enlista o muestra todos los elementos que esten en la tabla (base de datos en sqlite) """
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\nLa base de datos se abrió correctamente\n "
			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA")
			
			for i in cursor:
				print u"\nID = %s"%(i[0])
				print u"\nELEMENTO = %s"%(i[1])
				print u"\nIMAGEN = %s"%(i[2])
				print u"\nCARACTERISTICA = %s"%(i[3])
				print u"\nDESCRIPCION = %s"%(i[4])
				print u"\nUBICACION= %s"%(i[5])
				
			print u"\noperación satisfactoria\n\n"
			con.commit()
			con.close()			

			ID=input (" Dijite el ID del elemento que desea editar/modificar de la lista: ")
			
			"""esta funcion permite editar o modificar alguna caracteristica del elemento elejido en la lista anteriormente
			 mostrada"""

			while True:
				#esta funcion muestra el elemento que desea modificar o editar
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()
				os.system("cls")
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
			
				for i in cursor:
					print u"\nID = %s"%(i[0])
					print u"\nELEMENTO = %s"%(i[1])
					print u"\nIMAGEN = %s"%(i[2])
					print u"\nCARACTERISTICA = %s"%(i[3])
					print u"\nDESCRIPCION = %s"%(i[4])
					print u"\nUBICACION= %s"%(i[5])

				con.commit()
				con.close()

				print u"\n\n Qué Columna desea editar?\n 1. Nombre\n 2. Imagen/foto\n 3. Caracteristica\n 4. Descripción\n 5. Ubicación\n 6. Salir\n "
				opcion2=input(" Elija una opcion: " )
				os.system("cls")
				if opcion2==1:
					con=sqlite3.connect("inventarioElectronica")
					cursor = con.cursor()
					print u"\n IMPORTANTE:DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n"
					cambio=raw_input("Dijite el nuevo nombre del elemento: ")
					cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET ELEMENTO ='%s' WHERE ID='%s'"%(cambio,ID))
					cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
					print u"\nEl elemento se modifico correctamente\n"
				
					for i in cursor:
						print u"\nID = %s"%(i[0])
						print u"\nELEMENTO = %s"%(i[1])
						print u"\nIMAGEN = %s"%(i[2])
						print u"\nCARACTERISTICA = %s"%(i[3])
						print u"\nDESCRIPCION = %s"%(i[4])
						print u"\nUBICACION= %s"%(i[5])
					con.commit()
					con.close()
					os.system("pause")
					os.system("cls")

				elif opcion2==2:
					con=sqlite3.connect("inventarioElectronica")
					cursor = con.cursor()
					cambio=raw_input("Dijite la ubicacion de la nueva imagen del elemento: ")
					cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET IMAGEN ='%s' WHERE ID='%s'"%(cambio,ID))
					cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
					print u"\nEl elemento se modifico correctamente\n"
				
					for i in cursor:
						print u"\nID = %s"%(i[0])
						print u"\nELEMENTO = %s"%(i[1])
						print u"\nIMAGEN = %s"%(i[2])
						print u"\nCARACTERISTICA = %s"%(i[3])
						print u"\nDESCRIPCION = %s"%(i[4])
						print u"\nUBICACION= %s"%(i[5])
					con.commit()
					con.close()
					os.system("pause")
					os.system("cls")

				elif opcion2==3:
					con=sqlite3.connect("inventarioElectronica")
					cursor = con.cursor()
					cambio=raw_input("Dijite la nueva caracteristica del elemento: ")
					cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET CARACTERISTICA ='%s' WHERE ID='%s'"%(cambio,ID))
					cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
					print u"\nEl elemento se modifico correctamente\n"
				
					for i in cursor:
						print u"\nID = %s"%(i[0])
						print u"\nELEMENTO = %s"%(i[1])
						print u"\nIMAGEN = %s"%(i[2])
						print u"\nCARACTERISTICA = %s"%(i[3])
						print u"\nDESCRIPCION = %s"%(i[4])
						print u"\nUBICACION= %s"%(i[5])
					con.commit()
					con.close()
					os.system("pause")
					os.system("cls")

				elif opcion2==4:
					con=sqlite3.connect("inventarioElectronica")
					cursor = con.cursor()
					cambio=raw_input("Dijite la nueva descripcion del elemento: ")
					cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET DESCRIPCION ='%s' WHERE ID='%s'"%(cambio,ID))
					cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
					print u"\nEl elemento se modifico correctamente\n"
				
					for i in cursor:
						print u"\nID = %s"%(i[0])
						print u"\nELEMENTO = %s"%(i[1])
						print u"\nIMAGEN = %s"%(i[2])
						print u"\nCARACTERISTICA = %s"%(i[3])
						print u"\nDESCRIPCION = %s"%(i[4])
						print u"\nUBICACION= %s"%(i[5])
					con.commit()
					con.close()
					os.system("pause")
					os.system("cls")

				elif opcion2==5:
					con=sqlite3.connect("inventarioElectronica")
					cursor = con.cursor()
					cambio=raw_input("Dijite la nueva ubicacion del elemento: ")
					cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET UBICACION ='%s' WHERE ID='%s'"%(cambio,ID))
					cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
					print u"\nEl elemento se modifico correctamente\n"
				
					for i in cursor:
						print u"\nID = %s"%(i[0])
						print u"\nELEMENTO = %s"%(i[1])
						print u"\nIMAGEN = %s"%(i[2])
						print u"\nCARACTERISTICA = %s"%(i[3])
						print u"\nDESCRIPCION = %s"%(i[4])
						print u"\nUBICACION= %s"%(i[5])
					con.commit()
					con.close()
					os.system("pause")
					os.system("cls")
				else:
					break
			
		elif opcion1==2:
			"""Esta opcion enlista o muestra el elemento que este buscando el usuario, el cual se encuentra
			 en la tabla (base de datos en sqlite) """
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\n La base de datos se abrió correctamente\n "
			print u"\n IMPORTANTE:DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n"
			buscar=raw_input(" Ingrese el nombre del elemento que desea buscar: ")
			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ELEMENTO='%s'"%(buscar))
			
			for i in cursor:
				print u"\nID = %s"%(i[0])
				print u"\nELEMENTO = %s"%(i[1])
				print u"\nIMAGEN = %s"%(i[2])
				print u"\nCARACTERISTICA = %s"%(i[3])
				print u"\nDESCRIPCION = %s"%(i[4])
				print u"\nUBICACION= %s"%(i[5])
				
			print u"\noperación satisfactoria\n\n"
			con.commit()
			con.close()


			ID=input (" Dijite el ID del elemento que desea editar/modificar de la lista: ")

			
			"""esta funcion permite editar o modificar alguna caracteristica del elemento elejido en la lista anteriormente
			 mostrada"""

			while True:
				#esta funcion muestra el elemento que desea modificar o editar
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()				
				os.system("cls")
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
			
				for i in cursor:
					print u"\nID = %s"%(i[0])
					print u"\nELEMENTO = %s"%(i[1])
					print u"\nIMAGEN = %s"%(i[2])
					print u"\nCARACTERISTICA = %s"%(i[3])
					print u"\nDESCRIPCION = %s"%(i[4])
					print u"\nUBICACION= %s"%(i[5])

				con.commit()
				con.close()
				print u"\n\n Qué Columna desea editar?\n 1. Nombre\n 2. Imagen/foto\n 3. Caracteristica\n 4. Descripción\n 5. Ubicación\n 6. Salir\n "
				opcion2=input(" Elija una opcion: " )
				os.system("cls")
				if opcion2==1:
					con=sqlite3.connect("inventarioElectronica")
					cursor = con.cursor()
					print u"\n IMPORTANTE:DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n"
					cambio=raw_input("Dijite el nuevo nombre del elemento: ")
					cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET ELEMENTO ='%s' WHERE ID='%s'"%(cambio,ID))
					cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
					print u"\nEl elemento se modifico correctamente\n"
				
					for i in cursor:
						print u"\nID = %s"%(i[0])
						print u"\nELEMENTO = %s"%(i[1])
						print u"\nIMAGEN = %s"%(i[2])
						print u"\nCARACTERISTICA = %s"%(i[3])
						print u"\nDESCRIPCION = %s"%(i[4])
						print u"\nUBICACION= %s"%(i[5])
					con.commit()
					con.close()
					os.system("pause")
					os.system("cls")

				elif opcion2==2:
					con=sqlite3.connect("inventarioElectronica")
					cursor = con.cursor()
					cambio=raw_input("Dijite la ubicacion de la nueva imagen del elemento: ")
					cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET IMAGEN ='%s' WHERE ID='%s'"%(cambio,ID))
					cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
					print u"\nEl elemento se modifico correctamente\n"
				
					for i in cursor:
						print u"\nID = %s"%(i[0])
						print u"\nELEMENTO = %s"%(i[1])
						print u"\nIMAGEN = %s"%(i[2])
						print u"\nCARACTERISTICA = %s"%(i[3])
						print u"\nDESCRIPCION = %s"%(i[4])
						print u"\nUBICACION= %s"%(i[5])
					con.commit()
					con.close()
					os.system("pause")
					os.system("cls")

				elif opcion2==3:
					con=sqlite3.connect("inventarioElectronica")
					cursor = con.cursor()
					cambio=raw_input("Dijite la nueva caracteristica del elemento: ")
					cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET CARACTERISTICA ='%s' WHERE ID='%s'"%(cambio,ID))
					cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
					print u"\nEl elemento se modifico correctamente\n"
				
					for i in cursor:
						print u"\nID = %s"%(i[0])
						print u"\nELEMENTO = %s"%(i[1])
						print u"\nIMAGEN = %s"%(i[2])
						print u"\nCARACTERISTICA = %s"%(i[3])
						print u"\nDESCRIPCION = %s"%(i[4])
						print u"\nUBICACION= %s"%(i[5])
					con.commit()
					con.close()
					os.system("pause")
					os.system("cls")

				elif opcion2==4:
					con=sqlite3.connect("inventarioElectronica")
					cursor = con.cursor()
					cambio=raw_input("Dijite la nueva descripcion del elemento: ")
					cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET DESCRIPCION ='%s' WHERE ID='%s'"%(cambio,ID))
					cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
					print u"\nEl elemento se modifico correctamente\n"
				
					for i in cursor:
						print u"\nID = %s"%(i[0])
						print u"\nELEMENTO = %s"%(i[1])
						print u"\nIMAGEN = %s"%(i[2])
						print u"\nCARACTERISTICA = %s"%(i[3])
						print u"\nDESCRIPCION = %s"%(i[4])
						print u"\nUBICACION= %s"%(i[5])
					con.commit()
					con.close()
					os.system("pause")
					os.system("cls")

				elif opcion2==5:
					con=sqlite3.connect("inventarioElectronica")
					cursor = con.cursor()
					cambio=raw_input("Dijite la nueva ubicacion del elemento: ")
					cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET UBICACION ='%s' WHERE ID='%s'"%(cambio,ID))
					cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(ID))
					print u"\nEl elemento se modifico correctamente\n"
				
					for i in cursor:
						print u"\nID = %s"%(i[0])
						print u"\nELEMENTO = %s"%(i[1])
						print u"\nIMAGEN = %s"%(i[2])
						print u"\nCARACTERISTICA = %s"%(i[3])
						print u"\nDESCRIPCION = %s"%(i[4])
						print u"\nUBICACION= %s"%(i[5])
					con.commit()
					con.close()
					os.system("pause")
					os.system("cls")
				else:
					break
		else:
			os.system("cls")
			break
			
"""Este metodo va a permitir eliminar,borrar o suprimir algun elemento de la base de datos(tabla)"""
def borrarElemento ():
	os.system("cls")
	while True:
		print "\n 1. Mostrar Todos los elementos del inventario\n\n 2. Mostrar un elemento en especifico\n\n 3. Salir\n"
		opcion1=input(" Elija una opcion: ")
		os.system("cls")

		if opcion1==1:
			"""Esta opcion enlista o muestra todos los elementos que esten en la tabla (base de datos en sqlite) """
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\nLa base de datos se abrió correctamente\n "
			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA")
			

			for i in cursor:
				print "______________________________________________________________"
				print u"\nID = %s"%(i[0])
				print u"\nELEMENTO = %s"%(i[1])
				print u"\nIMAGEN = %s"%(i[2])
				print u"\nCARACTERISTICA = %s"%(i[3])
				print u"\nDESCRIPCION = %s"%(i[4])
				print u"\nUBICACION= %s"%(i[5])
				
			con.commit()
			con.close()

			#esta función borra el elemento que usted elija de la lista anteriormente mostrada
			print u"\n Qué Elemento desea borrar de la lista?\n"
			borrar=raw_input(" Digite el ID del elemento que desea borrar: ")
			os.system("cls")
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\nLa base de datos se abrió correctamente\n "
			cursor.execute("DELETE FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(borrar))
			print u"\nElemento Eliminado con exito, así quedo la nueva tabla\n"	

			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA")
			for i in cursor:
				print "______________________________________________________________"
				print u"\nID = %s"%(i[0])
				print u"\nELEMENTO = %s"%(i[1])
				print u"\nIMAGEN = %s"%(i[2])
				print u"\nCARACTERISTICA = %s"%(i[3])
				print u"\nDESCRIPCION = %s"%(i[4])
				print u"\nUBICACION= %s"%(i[5])

			#esta funcion me permite contar todos los elementos del la tabla antes mostrada
			cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA")      
			row = cursor.fetchone()
			print u"\n\nHay un total de %s elementos de los seleccionados en el inventario\n "%(row[0]) 	
			print u"\noperación satisfactoria\n"
			con.commit()
			con.close()				
			os.system("pause")
			os.system("cls")

		elif opcion1==2:
			"""Esta opcion enlista o muestra el elemento que este buscando el usuario, el cual se encuentra
			 en la tabla (base de datos en sqlite) """
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\n La base de datos se abrió correctamente\n "
			print u"\n IMPORTANTE:DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n"
			buscar=raw_input(" Ingrese el NOMBRE del elemento que desea buscar: ")
			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ELEMENTO='%s'"%(buscar))
		
			for i in cursor:
				print "______________________________________________________________"
				print u"ID = %s"%(i[0])
				print u"\nELEMENTO = %s"%(i[1])
				print u"\nIMAGEN = %s"%(i[2])
				print u"\nCARACTERISTICA = %s"%(i[3])
				print u"\nDESCRIPCION = %s"%(i[4])
				print u"\nUBICACION= %s"%(i[5])
			con.commit()
			con.close()

			print u"\n Qué Elemento desea borrar de la lista?\n"
			borrar=raw_input(" Digite el ID del elemento que desea borrar: ")
			os.system("cls")
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\nLa base de datos se abrió correctamente\n "
			cursor.execute("DELETE FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(borrar))
			print u"\nElemento Eliminado con exito, así quedo la nueva tabla\n"	

			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ELEMENTO='%s'"%(buscar))				
			for i in cursor:
				print "______________________________________________________________"
				print u"\nID = %s"%(i[0])
				print u"\nELEMENTO = %s"%(i[1])
				print u"\nIMAGEN = %s"%(i[2])
				print u"\nCARACTERISTICA = %s"%(i[3])
				print u"\nDESCRIPCION = %s"%(i[4])
				print u"\nUBICACION= %s"%(i[5])

			#esta funcion me permite contar todos los elementos del la tabla antes mostrada
			cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA  WHERE ELEMENTO='%s'"%(buscar))      
			row = cursor.fetchone()
			print u"\n\nHay un total de %s elementos de los seleccionados en el inventario\n "%(row[0]) 

			print u"\noperación satisfactoria\n"
			con.commit()
			con.close()				
			os.system("pause")
			os.system("cls")
		else:
			os.system("cls")
			break

"""Este metodo va a permitir listar o mostrar uno o mas elementos creados en la base de datos(tabla)"""	

def listarElementos ():
	os.system("cls")
	while True:
		print "\n 1. Listar Todos los elementos del inventario\n\n 2. Listar un elemento en especifico\n\n 3. Salir\n"
		opcion1=input(" Elija una opcion: ")

		if opcion1==1:
			os.system("cls")
			"""Esta opcion enlista o muestra todos los elementos que esten en la tabla (base de datos en sqlite) """
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\nLa base de datos se abrió correctamente\n "
			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA")
			
			for i in cursor:
				print "______________________________________________________________"
				print u"\nID = %s"%(i[0])
				print u"\nELEMENTO = %s"%(i[1])
				print u"\nIMAGEN = %s"%(i[2])
				print u"\nCARACTERISTICA = %s"%(i[3])
				print u"\nDESCRIPCION = %s"%(i[4])
				print u"\nUBICACION= %s"%(i[5])

			#esta funcion me permite contar todos los elementos del la tabla antes mostrada
			cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA")      
			row = cursor.fetchone()
			print u"\n\nHay un total de %s elementos en el inventario\n "%(row[0]) 	

			print u"\noperación satisfactoria\n"
			con.commit()
			con.close()
			os.system("pause")

		elif opcion1==2:
			os.system("cls")
			"""Esta opcion enlista o muestra el elemento que este buscando el usuario, el cual se encuentra
			 en la tabla (base de datos en sqlite) """
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\n La base de datos se abrió correctamente\n "
			print u"\n IMPORTANTE:DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n"
			buscar=raw_input(" Ingrese el NOMBRE del elemento que desea buscar: ")
			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ELEMENTO='%s'"%(buscar))
			"""la funcion "con.total" cuenta los elementos de la tabla y muestra el numero de elmentos que
			 hay en la pantalla."""
			#print "\n Hay un total de %s elementos en el inventario\n "%(con.total)

			for i in cursor:
				print "______________________________________________________________"
				print u"\nID = %s"%(i[0])
				print u"\nELEMENTO = %s"%(i[1])
				print u"\nIMAGEN = %s"%(i[2])
				print u"\nCARACTERISTICA = %s"%(i[3])
				print u"\nDESCRIPCION = %s"%(i[4])
				print u"\nUBICACION= %s"%(i[5])

			#esta funcion me permite contar todos los elementos del la tabla antes mostrada
			cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA  WHERE ELEMENTO='%s'"%(buscar))      
			row = cursor.fetchone()
			print u"\n\nHay un total de %s elementos de los seleccionados en el inventario\n "%(row[0]) 
				
			print u"\noperación satisfactoria\n"
			con.commit()
			con.close()
			os.system("pause")
		else:
			os.system("cls")
			break


"""Menu del programa, aqui estaran todas las opciones del programa, y sera el lugar donde el usuario puede interactuar
 con las bases de datos y todas sus funciones """
while True:
	os.system("cls")
	
	#instruccion para que el usuario cree la tabla si aun no la tiene en su ordenador, si ya la tiene continua con el programa
	print "\n              INVENTARIO DE ELEMENTOS ELECTRONICOS\n"
	print "\n Por favor, antes de continuar con el programa, revise si ya tiene creada en su\n ordenador la tabla del inventario electronico, si no es asi por favor cree la\n tabla y continue con el programa, gracias.\n"
	print "\n 0. Crear Tabla del Inventario\n\n "
	print "\n 1. Agrear un Elemento\n\n 2. Editar Elementos\n\n 3. Eliminar un Elemento\n\n 4. Listar Elementos \n\n 5. Salir\n"
	opcion=input(" Elija una opcion segun las instrucciones anteriormente dadas: ")
	if opcion==0:
		crear_Tabla()
	# menu de opciones con los cuales el usuario va a interactuar con las funciones del programa
	if opcion==1:
		os.system("cls")
		"""creacion del elemento por parte del usuario, aqui se asignan todos los datos necesarios por el usuario 
		que se requieren para la creacion del elemento y se guardan en el metodo "agregarElemento" de la clase 
		"elemento". """
		print "\n Complete todos los datos del elemento\n"
		print u"\n IMPORTANTE:DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n"
		nombre=raw_input(" Ingrese el nombre del elemento: ")
		print "\n"
		imagen=raw_input(" Ingrese la ubicacion de la imagen o foto del elemento: ")
		print "\n"
		caracteristica=raw_input(" Ingrese la caracteristica del elemento: ")
		print "\n"
		descripcion=raw_input(" Ingrese la descripcion del elemento: ")
		print "\n"
		ubicacion=raw_input(" Ingrese la ubicacion del elemento: ")
		componente=elemento(nombre,imagen,caracteristica,descripcion,ubicacion)
		componente.agregarElemento()
				
	elif opcion==2:
		editarElemento()
		

	elif opcion==3:
		borrarElemento()
		

	elif opcion==4:
		listarElementos()		
		
	else:
		os.system("cls")
		break

print "\n Hasta pronto...................................................."



		