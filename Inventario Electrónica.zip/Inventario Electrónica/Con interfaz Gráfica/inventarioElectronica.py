
# -*- coding: utf-8 -*-
""" Aqui se importan librerias para ser utilizadas en los metodos y clases"""
from Tkinter import *
from tkFileDialog import askopenfilename, asksaveasfilename
import tkMessageBox
import sqlite3
import os

"""CREAR LA TABLA EN LA QUE ESTARAN LISTADOS TODOS LOS ELEMENTOS, esto solo se hara una unica vez durante la utilizacion
del programa, si la tabla ya se encuentra creada, no hay nececidad de ejecutar esta funcion"""

def crear_Tabla ( ):

		con=sqlite3.connect("inventarioElectronica")
		cursor = con.cursor()

		print u"\nLa base de datos se abrio correctamente"

		cursor.execute('''CREATE TABLE INVENTARIO_ELECTRONICA
			(ID INTEGER PRIMARY KEY  AUTOINCREMENT,
			ELEMENTO TEXT  NOT NULL,
			IMAGEN     TEXT,
			CARACTERISTICA     TEXT,
			DESCRIPCION    TEXT,
			UBICACION   TEXT)''')

		print u"\n Tabla creada con éxito\n"
		con.close()
		print " Ya puede continuar utilizando las demas funciones del programa, gracias\n"
		os.system("pause")
		tkMessageBox.showinfo("informacion"," Tabla Creada con exito" )
		
"""Clase en la cual se va hacer la definicion de parametros en donde se haran las respectivas conexiones a la base de datos desde agregar el elemento hasta listar,
editar y borrar el elemento o caracteristica de este"""


		
""" Clase en la cual se va hacer la definicion de parametros en donde se va a crear el elemento"""
class elemento():
	"""Metodo constructor de un elemento nuevo, todos los elementos creados van a tener los atributos 
	asiganados en esta funcion(metodo)  """

	def __init__(self,nombre,imagen,caracteristica,descripcion,ubicacion):

		self.nombre=nombre
		self.imagen=imagen
		self.caracteristica=caracteristica
		self.descripcion=descripcion
		self.ubicacion=ubicacion

	"""Este metodo va a permitir agregar o insertar los elementos creados a la base de datos(tabla)"""
	def agregarElemento (self):
			os.system("cls")
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\n La base de datos se abrió correctamente\n "
			cursor.execute('''INSERT INTO INVENTARIO_ELECTRONICA ( ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION) \
		                   VALUES ('%s', '%s', '%s', '%s', '%s')'''%(componente.nombre, componente.imagen, componente.caracteristica, componente.descripcion, componente.ubicacion))	
			con.commit()
			con.cursor()
			print u" Elemento guardado correctamente...\n"
			tkMessageBox.showinfo("informacion"," Elemento agregado con exito,\nPuede continuar agragando elementos\n o ya puede cerrar esta ventana" )
			os.system("cls")
			
		

"""NOTA: Todos los metodos creados a continuacion van a ser creados fuera de la clase "elemento", esto para un mejor
funcionamiento del programa y por problemas durante la buena funcion de cada metodo. """


"""Este metodo va a permitir editar o modificar los elementos creados a la base de datos, ya sea nombre,
 descripcion, caracteristica, imagen o ubicacion en la base de datos(tabla)"""
def editarElemento ():

	#creacion de funcion para llamar todos los elemento de la tabla
	def verTodo():
		ventana3=Toplevel(root)
		ventana3.title("Eliminar Elemento")
		ventana3.geometry("1000x650+200+10")
		icono = ventana3.iconbitmap("icono.ico")
		#creacion de barras de desplazamiento
		yscrollbar = Scrollbar(ventana3)
		yscrollbar.grid(row=1, column=4,sticky=NS)

		xscrollbar = Scrollbar(ventana3,orient=HORIZONTAL)
		xscrollbar.grid(row=2,column=1, columnspan=4, sticky=NE+NW)

	#crear lista
		listaElementos=Listbox(ventana3, width=163, height=30,yscrollcommand=yscrollbar.set,xscrollcommand=xscrollbar.set)

		def editar1():
			#creacion de variables
			nombre=StringVar()
			imagen=StringVar()
			caracteristica=StringVar()
			descripcion=StringVar()
			ubicacion=StringVar()

			ventana2=Toplevel(root)
			ventana2.title("Elemento Nuevo")
			ventana2.geometry("1100x500+200+30")
			icono = ventana2.iconbitmap("icono.ico")
			#crear lista
			listaElementos=Listbox(ventana2, width=163, height=10,yscrollcommand=yscrollbar.set,xscrollcommand=xscrollbar.set)

			def editarNombre():
				listaElementos.delete(0,END)
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()
				cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET ELEMENTO ='%s' WHERE ID='%s'"%(nombre.get(),editar.get()))
				print u"\nLa base de datos se abrió correctamente\n "
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
				
				for i in cursor:
					n=0  
					listaElementos.insert(n,"_________________________________________________________________________________________________----")
					n=n+1
					listaElementos.insert(n,"\nID = %s"%(i[0]))
					n=n+1
					listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
					n=n+1
					listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
					n=n+1
					listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
					n=n+1
					listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
					n=n+1
					listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
					n=n+1

				listaElementos.grid(row=1,column=1,columnspan=3)

				print u"\noperación satisfactoria\n"
				con.commit()
				con.close()	

			def editarImagen():
				listaElementos.delete(0,END)
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()
				cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET IMAGEN ='%s' WHERE ID='%s'"%(imagen.get(),editar.get()))
				
				print u"\nLa base de datos se abrió correctamente\n "
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
				
				for i in cursor:
					n=0  
					listaElementos.insert(n,"_________________________________________________________________________________________________----")
					n=n+1
					listaElementos.insert(n,"\nID = %s"%(i[0]))
					n=n+1
					listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
					n=n+1
					listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
					n=n+1
					listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
					n=n+1
					listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
					n=n+1
					listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
					n=n+1

				listaElementos.grid(row=1,column=1,columnspan=3)

				print u"\noperación satisfactoria\n"
				con.commit()
				con.close()	

			def editarCaracteristica():
				listaElementos.delete(0,END)
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()
				cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET CARACTERISTICA ='%s' WHERE ID='%s'"%(caracteristica.get(),editar.get()))

				print u"\nLa base de datos se abrió correctamente\n "
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
				
				for i in cursor:
					n=0  
					listaElementos.insert(n,"_________________________________________________________________________________________________----")
					n=n+1
					listaElementos.insert(n,"\nID = %s"%(i[0]))
					n=n+1
					listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
					n=n+1
					listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
					n=n+1
					listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
					n=n+1
					listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
					n=n+1
					listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
					n=n+1

				listaElementos.grid(row=1,column=1,columnspan=3)

				print u"\noperación satisfactoria\n"
				con.commit()
				con.close()	

			def editarDescripcion():
				listaElementos.delete(0,END)
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()
				cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET DESCRIPCION ='%s' WHERE ID='%s'"%(descripcion.get(),editar.get()))
				print u"\nLa base de datos se abrió correctamente\n "
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
				
				for i in cursor:
					n=0  
					listaElementos.insert(n,"_________________________________________________________________________________________________----")
					n=n+1
					listaElementos.insert(n,"\nID = %s"%(i[0]))
					n=n+1
					listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
					n=n+1
					listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
					n=n+1
					listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
					n=n+1
					listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
					n=n+1
					listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
					n=n+1

				listaElementos.grid(row=1,column=1,columnspan=3)

				print u"\noperación satisfactoria\n"
				con.commit()
				con.close()	

			def editarUbicacion():
				listaElementos.delete(0,END)
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()
				cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET UBICACION ='%s' WHERE ID='%s'"%(ubicacion.get(),editar.get()))
				print u"\nLa base de datos se abrió correctamente\n "
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
				
				for i in cursor:
					n=0  
					listaElementos.insert(n,"_________________________________________________________________________________________________----")
					n=n+1
					listaElementos.insert(n,"\nID = %s"%(i[0]))
					n=n+1
					listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
					n=n+1
					listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
					n=n+1
					listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
					n=n+1
					listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
					n=n+1
					listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
					n=n+1

				listaElementos.grid(row=1,column=1,columnspan=3)

				print u"\noperación satisfactoria\n"
				con.commit()
				con.close()	

			def salir():
				tkMessageBox.showinfo("GUARDADO"," Guardado con EXITO!!\n Cierre la ventana con la X\n en la parte superior\n derecha, gracias" )





			"""creacion del elemento por parte del usuario, aqui se asignan todos los datos necesarios por el usuario 
			que se requieren para la creacion del elemento y se guardan en el metodo "agregarElemento" de la clase 
			"elemento". """

			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\nLa base de datos se abrió correctamente\n "
			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
			
			for i in cursor:
				n=0  
				listaElementos.insert(n,"_________________________________________________________________________________________________----")
				n=n+1
				listaElementos.insert(n,"\nID = %s"%(i[0]))
				n=n+1
				listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
				n=n+1
				listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
				n=n+1
				listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
				n=n+1
				listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
				n=n+1
				listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
				n=n+1

			listaElementos.grid(row=1,column=1,columnspan=3)

			print u"\noperación satisfactoria\n"
			con.commit()
			con.close()	



		#creacion de etiquetas
			etiqueta1=Label(ventana2,text="\n Complete los datos que desea cambiar del elemento\n",font="15").grid(row=2, column=1, columnspan=2)
			etiqueta2=Label(ventana2,text="\n IMPORTANTE: DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n",font="15", fg="blue").grid(row=3, column=1, columnspan=2)
			etiqueta3=Label(ventana2,text=" Ingrese el nuevo nombre del elemento: ",font="15").grid(row=4, column=1,sticky=W)
			etiqueta4=Label(ventana2,text=" Ingrese la nueva ubicacion de la imagen o foto del elemento: ",font="15").grid(row=5, column=1,sticky=W)
			etiqueta5=Label(ventana2,text=" Ingrese la nueva caracteristica del elemento: ",font="15").grid(row=6, column=1,sticky=W)
			etiqueta6=Label(ventana2,text=" Ingrese la nueva descripcion del elemento: ",font="15").grid(row=7, column=1,sticky=W)
			etiqueta7=Label(ventana2,text=" Ingrese la nueva ubicacion del elemento: ",font="15").grid(row=8, column=1,sticky=W)


		#creacion de cuadros de texto
			nombre1=Entry(ventana2, textvariable=nombre,width=80).grid(row=4, column=2,sticky=W)
			imagen1=Entry(ventana2, textvariable=imagen,width=80).grid(row=5, column=2,sticky=W)
			caracteristica1=Entry(ventana2, textvariable=caracteristica,width=80).grid(row=6, column=2,sticky=W)
			descripcion1=Entry(ventana2, textvariable=descripcion,width=80).grid(row=7, column=2,sticky=W)
			ubicacion1=Entry(ventana2, textvariable=ubicacion,width=80).grid(row=8, column=2,sticky=NW)

		#boton que hace la funcion de pasar los datos de las variables al metodo enviarAgregar
			botonCambiar=Button(ventana2, text="Cambiar",width=20,command=editarNombre,fg="blue")
			botonCambiar.grid(row=4,column=3)
			botonCambiar1=Button(ventana2, text="Cambiar",width=20,command=editarImagen,fg="blue")
			botonCambiar1.grid(row=5,column=3)
			botonCambiar2=Button(ventana2, text="Cambiar",width=20,command=editarCaracteristica,fg="blue")
			botonCambiar2.grid(row=6,column=3)
			botonCambiar3=Button(ventana2, text="Cambiar",width=20,command=editarDescripcion,fg="blue")
			botonCambiar3.grid(row=7,column=3)
			botonCambiar4=Button(ventana2, text="Cambiar",width=20,command=editarUbicacion,fg="blue")
			botonCambiar4.grid(row=8,column=3)

			botonSalir=Button(ventana2,text="Guardar y Salir", width=25,command=salir, fg="blue")
			botonSalir.grid(row=9,column=3,sticky=E)
						
						
			os.system("cls")

			ventana2.transient(root)




		os.system("cls")
		"""Esta opcion enlista o muestra todos los elementos que esten en la tabla (base de datos en sqlite) """
		con=sqlite3.connect("inventarioElectronica")
		cursor = con.cursor()
		print u"\nLa base de datos se abrió correctamente\n "
		cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA ")
		
		for i in cursor:
			n=0  
			listaElementos.insert(n,"_________________________________________________________________________________________________----")
			n=n+1
			listaElementos.insert(n,"\nID = %s"%(i[0]))
			n=n+1
			listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
			n=n+1
			listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
			n=n+1
			listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
			n=n+1
			listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
			n=n+1
			listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
			n=n+1

		listaElementos.grid(row=1,column=1, columnspan=3)

		#esta funcion me permite contar todos los elementos del la tabla antes mostrada
		cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA")      
		row = cursor.fetchone()
		etiqueta1=Label(ventana3,text="\nHay un total de %s elementos en el inventario\n "%(row[0])).grid(row=3,column=1, columnspan=3) 
		etiqueta1=Label(ventana3,text="Qué elemento desea Editar? ", font="15", fg="blue").grid(row=4,column=1, columnspan=3)

		editar=StringVar()
		etiqueta5=Label(ventana3,text="\n Digite el ID del elemento que desea Eliminar\n").grid(row=5, column=1)
		buscar1=Entry(ventana3, textvariable=editar, width=70).grid(row=5, column=2,sticky=W)

		botonBorrar=Button(ventana3,text="Editar",width=20,command=editar1, fg="blue")
		botonBorrar.grid(row=5,column=3,sticky=W) 

		print u"\noperación satisfactoria\n"
		con.commit()
		con.close()
		xscrollbar.config(command=listaElementos.xview)
		yscrollbar.config(command=listaElementos.yview)
		ventana3.transient(root)

#creacion de funcion para llamar un elemento en espescifico de la tabla
	def verUno():		
		ventana3=Toplevel(root)
		ventana3.title("ELiminar Elemento")
		ventana3.geometry("950x650+200+10")
		icono = ventana3.iconbitmap("icono.ico")

		#creacion barra de desplazamiento
		yscrollbar = Scrollbar(ventana3)
		yscrollbar.grid(row=1, column=4,sticky=NS)

		xscrollbar = Scrollbar(ventana3,orient=HORIZONTAL)
		xscrollbar.grid(row=2,column=1, columnspan=4, sticky=NE+NW)
	
	#crear lista
		listaElementos=Listbox(ventana3, width=155, height=30, yscrollcommand=yscrollbar.set, xscrollcommand=xscrollbar.set)
		"""Esta opcion enlista o muestra el elemento que este buscando el usuario, el cual se encuentra
		 en la tabla (base de datos en sqlite) """

		def editar2():
			#creacion de variables
			nombre=StringVar()
			imagen=StringVar()
			caracteristica=StringVar()
			descripcion=StringVar()
			ubicacion=StringVar()

			ventana2=Toplevel(root)
			ventana2.title("Elemento Nuevo")
			ventana2.geometry("1100x500+200+30")
			icono = ventana2.iconbitmap("icono.ico")
			#crear lista
			listaElementos=Listbox(ventana2, width=163, height=10,yscrollcommand=yscrollbar.set,xscrollcommand=xscrollbar.set)

			def editarNombre():
				listaElementos.delete(0,END)
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()
				cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET ELEMENTO ='%s' WHERE ID='%s'"%(nombre.get(),editar.get()))
				print u"\nLa base de datos se abrió correctamente\n "
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
				
				for i in cursor:
					n=0  
					listaElementos.insert(n,"_________________________________________________________________________________________________----")
					n=n+1
					listaElementos.insert(n,"\nID = %s"%(i[0]))
					n=n+1
					listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
					n=n+1
					listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
					n=n+1
					listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
					n=n+1
					listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
					n=n+1
					listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
					n=n+1

				listaElementos.grid(row=1,column=1,columnspan=3)

				print u"\noperación satisfactoria\n"
				con.commit()
				con.close()	

			def editarImagen():
				listaElementos.delete(0,END)
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()
				cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET IMAGEN ='%s' WHERE ID='%s'"%(imagen.get(),editar.get()))
				
				print u"\nLa base de datos se abrió correctamente\n "
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
				
				for i in cursor:
					n=0  
					listaElementos.insert(n,"_________________________________________________________________________________________________----")
					n=n+1
					listaElementos.insert(n,"\nID = %s"%(i[0]))
					n=n+1
					listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
					n=n+1
					listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
					n=n+1
					listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
					n=n+1
					listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
					n=n+1
					listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
					n=n+1

				listaElementos.grid(row=1,column=1,columnspan=3)

				print u"\noperación satisfactoria\n"
				con.commit()
				con.close()	

			def editarCaracteristica():
				listaElementos.delete(0,END)
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()
				cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET CARACTERISTICA ='%s' WHERE ID='%s'"%(caracteristica.get(),editar.get()))

				print u"\nLa base de datos se abrió correctamente\n "
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
				
				for i in cursor:
					n=0  
					listaElementos.insert(n,"_________________________________________________________________________________________________----")
					n=n+1
					listaElementos.insert(n,"\nID = %s"%(i[0]))
					n=n+1
					listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
					n=n+1
					listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
					n=n+1
					listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
					n=n+1
					listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
					n=n+1
					listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
					n=n+1

				listaElementos.grid(row=1,column=1,columnspan=3)

				print u"\noperación satisfactoria\n"
				con.commit()
				con.close()	

			def editarDescripcion():
				listaElementos.delete(0,END)
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()
				cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET DESCRIPCION ='%s' WHERE ID='%s'"%(descripcion.get(),editar.get()))
				print u"\nLa base de datos se abrió correctamente\n "
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
				
				for i in cursor:
					n=0  
					listaElementos.insert(n,"_________________________________________________________________________________________________----")
					n=n+1
					listaElementos.insert(n,"\nID = %s"%(i[0]))
					n=n+1
					listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
					n=n+1
					listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
					n=n+1
					listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
					n=n+1
					listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
					n=n+1
					listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
					n=n+1

				listaElementos.grid(row=1,column=1,columnspan=3)

				print u"\noperación satisfactoria\n"
				con.commit()
				con.close()	

			def editarUbicacion():
				listaElementos.delete(0,END)
				con=sqlite3.connect("inventarioElectronica")
				cursor = con.cursor()
				cursor.execute("UPDATE INVENTARIO_ELECTRONICA SET UBICACION ='%s' WHERE ID='%s'"%(ubicacion.get(),editar.get()))
				print u"\nLa base de datos se abrió correctamente\n "
				cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
				
				for i in cursor:
					n=0  
					listaElementos.insert(n,"_________________________________________________________________________________________________----")
					n=n+1
					listaElementos.insert(n,"\nID = %s"%(i[0]))
					n=n+1
					listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
					n=n+1
					listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
					n=n+1
					listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
					n=n+1
					listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
					n=n+1
					listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
					n=n+1

				listaElementos.grid(row=1,column=1,columnspan=3)

				print u"\noperación satisfactoria\n"
				con.commit()
				con.close()	

			def salir():
				tkMessageBox.showinfo("GUARDADO"," Guardado con EXITO!!\n Cierre la ventana con la X\n en la parte superior\n derecha, gracias" )





			"""creacion del elemento por parte del usuario, aqui se asignan todos los datos necesarios por el usuario 
			que se requieren para la creacion del elemento y se guardan en el metodo "agregarElemento" de la clase 
			"elemento". """

			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\nLa base de datos se abrió correctamente\n "
			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(editar.get()))
			
			for i in cursor:
				n=0  
				listaElementos.insert(n,"_________________________________________________________________________________________________----")
				n=n+1
				listaElementos.insert(n,"\nID = %s"%(i[0]))
				n=n+1
				listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
				n=n+1
				listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
				n=n+1
				listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
				n=n+1
				listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
				n=n+1
				listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
				n=n+1

			listaElementos.grid(row=1,column=1,columnspan=3)

			print u"\noperación satisfactoria\n"
			con.commit()
			con.close()	



		#creacion de etiquetas
			etiqueta1=Label(ventana2,text="\n Complete los datos que desea cambiar del elemento\n",font="15").grid(row=2, column=1, columnspan=2)
			etiqueta2=Label(ventana2,text="\n IMPORTANTE: DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n",font="15", fg="blue").grid(row=3, column=1, columnspan=2)
			etiqueta3=Label(ventana2,text=" Ingrese el nuevo nombre del elemento: ",font="15").grid(row=4, column=1,sticky=W)
			etiqueta4=Label(ventana2,text=" Ingrese la nueva ubicacion de la imagen o foto del elemento: ",font="15").grid(row=5, column=1,sticky=W)
			etiqueta5=Label(ventana2,text=" Ingrese la nueva caracteristica del elemento: ",font="15").grid(row=6, column=1,sticky=W)
			etiqueta6=Label(ventana2,text=" Ingrese la nueva descripcion del elemento: ",font="15").grid(row=7, column=1,sticky=W)
			etiqueta7=Label(ventana2,text=" Ingrese la nueva ubicacion del elemento: ",font="15").grid(row=8, column=1,sticky=W)


		#creacion de cuadros de texto
			nombre1=Entry(ventana2, textvariable=nombre,width=80).grid(row=4, column=2,sticky=W)
			imagen1=Entry(ventana2, textvariable=imagen,width=80).grid(row=5, column=2,sticky=W)
			caracteristica1=Entry(ventana2, textvariable=caracteristica,width=80).grid(row=6, column=2,sticky=W)
			descripcion1=Entry(ventana2, textvariable=descripcion,width=80).grid(row=7, column=2,sticky=W)
			ubicacion1=Entry(ventana2, textvariable=ubicacion,width=80).grid(row=8, column=2,sticky=NW)

		#boton que hace la funcion de pasar los datos de las variables al metodo enviarAgregar
			botonCambiar=Button(ventana2, text="Cambiar",width=20,command=editarNombre,fg="blue")
			botonCambiar.grid(row=4,column=3)
			botonCambiar1=Button(ventana2, text="Cambiar",width=20,command=editarImagen,fg="blue")
			botonCambiar1.grid(row=5,column=3)
			botonCambiar2=Button(ventana2, text="Cambiar",width=20,command=editarCaracteristica,fg="blue")
			botonCambiar2.grid(row=6,column=3)
			botonCambiar3=Button(ventana2, text="Cambiar",width=20,command=editarDescripcion,fg="blue")
			botonCambiar3.grid(row=7,column=3)
			botonCambiar4=Button(ventana2, text="Cambiar",width=20,command=editarUbicacion,fg="blue")
			botonCambiar4.grid(row=8,column=3)

			botonSalir=Button(ventana2,text="Guardar y Salir", width=25,command=salir, fg="blue")
			botonSalir.grid(row=9,column=3,sticky=E)
						
						
			os.system("cls")

			ventana2.transient(root)
		
		con=sqlite3.connect("inventarioElectronica")
		cursor = con.cursor()
		print u"\n La base de datos se abrió correctamente\n "
		cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ELEMENTO='%s'"%(buscar1.get()))
		"""la funcion "con.total" cuenta los elementos de la tabla y muestra el numero de elmentos que
		 hay en la pantalla."""
		#print "\n Hay un total de %s elementos en el inventario\n "%(con.total)

		for i in cursor:
			n=0  
			listaElementos.insert(n,"_________________________________________________________________________________________________----")
			n=n+1
			listaElementos.insert(n,"\nID = %s"%(i[0]))
			n=n+1
			listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
			n=n+1
			listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
			n=n+1
			listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
			n=n+1
			listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
			n=n+1
			listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
			n=n+1

		listaElementos.grid(row=1, column=1, columnspan=3)
	#esta funcion me permite contar todos los elementos del la tabla antes mostrada
		cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA WHERE ELEMENTO='%s'"%(buscar1.get()))      
		row = cursor.fetchone()
		etiqueta1=Label(ventana3,text="\nHay un total de %s elementos en el inventario\n "%(row[0])).grid(row=3,column=1, columnspan=3) 
		etiqueta1=Label(ventana3,text="Qué elemento desea editar? ", font="15", fg="blue").grid(row=4,column=1, columnspan=3)

		editar=StringVar()
		etiqueta5=Label(ventana3,text="\n Digite el ID del elemento que desea editar\n").grid(row=5, column=1)
		buscar3=Entry(ventana3, textvariable=editar, width=70).grid(row=5, column=2,sticky=W)

		botonEditar1=Button(ventana3,text="Editar",width=20,command=editar2, fg="blue")
		botonEditar1.grid(row=5,column=3,sticky=W) 

		print u"\noperación satisfactoria\n"
		con.commit()
		con.close()

		xscrollbar.config(command=listaElementos.xview)
		yscrollbar.config(command=listaElementos.yview)
		ventana3.transient(root)

	def Salir():
		tkMessageBox.showinfo("informacion"," Cierre la ventana con la X\n en la parte superior\n derecha, gracias" )



# creacion de ventana de opciones
	ventana4=Toplevel(root)
	ventana4.title("Editar Elmento")
	ventana4.geometry("500x300+500+200")
	icono = ventana4.iconbitmap("icono.ico")
	etiqueta1=Label(ventana4,text=" Listar Todos los elementos del inventario",font="15").grid(row=1, column=2,sticky=W)
	etiqueta2=Label(ventana4,text=" \n\nListar un elemento en especifico ",font="15").grid(row=2, column=1, columnspan=2)

	etiqueta3=Label(ventana4,text=" ",font="15").grid(row=6, column=2, columnspan=2, sticky=W)

	etiqueta4=Label(ventana4,text=" Salir ",font="15").grid(row=7, column=2,sticky=W)

	buscar1=StringVar()
	etiqueta5=Label(ventana4,text="\n IMPORTANTE:DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n", fg="blue").grid(row=3, column=1, columnspan=2)
	etiqueta6=Label(ventana4,text=" Ingrese el NOMBRE del elemento que desea buscar:\n").grid(row=4, column=1, columnspan=2)
	buscar2=Entry(ventana4, textvariable=buscar1, width=50).grid(row=5, column=1, columnspan=2)

	botonBuscar=Button(ventana4,text="BUSCAR",width=10,command=verUno, fg="blue")
	botonBuscar.grid(row=5,column=2,sticky=E)
	
	botonTodo=Button(ventana4,text="<O>",width=5,command=verTodo, fg="blue")
	botonTodo.grid(row=1,column=1,sticky=E)

	botonSalir=Button(ventana4,text="<O>", width=5,command=Salir, fg="blue")
	botonSalir.grid(row=7,column=1,sticky=E)

	ventana4.transient(root)
	
			
"""Este metodo va a permitir eliminar,borrar o suprimir algun elemento de la base de datos(tabla)"""
def borrarElemento ():
	#creacion de funcion para llamar todos los elemento de la tabla
	def verTodo():
		ventana3=Toplevel(root)
		ventana3.title("Eliminar Elemento")
		ventana3.geometry("1000x650+200+10")
		icono = ventana3.iconbitmap("icono.ico")
		#creacion de barras de desplazamiento
		yscrollbar = Scrollbar(ventana3)
		yscrollbar.grid(row=1, column=4,sticky=NS)

		xscrollbar = Scrollbar(ventana3,orient=HORIZONTAL)
		xscrollbar.grid(row=2,column=1, columnspan=4, sticky=NE+NW)

	#crear lista
		listaElementos=Listbox(ventana3, width=163, height=30,yscrollcommand=yscrollbar.set,xscrollcommand=xscrollbar.set)

		def eliminar():
			listaElementos.delete(0,END)
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\nLa base de datos se abrió correctamente\n "
			cursor.execute("DELETE FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(borrar.get()))
			print u"\nElemento Eliminado con exito, así quedo la nueva tabla\n"	

			tkMessageBox.showinfo("informacion"," Elemento eliminado con exito" )

			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA")
			
			for i in cursor:
				n=0  
				listaElementos.insert(n,"_________________________________________________________________________________________________----")
				n=n+1
				listaElementos.insert(n,"\nID = %s"%(i[0]))
				n=n+1
				listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
				n=n+1
				listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
				n=n+1
				listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
				n=n+1
				listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
				n=n+1
				listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
				n=n+1

			listaElementos.grid(row=1,column=1,columnspan=3)

			#esta funcion me permite contar todos los elementos del la tabla antes mostrada
			cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA")      
			row = cursor.fetchone()

			etiqueta1=Label(ventana3,text="\nHay un total de %s elementos en el inventario\n "%(row[0])).grid(row=3,column=1, columnspan=3)

			print u"\noperación satisfactoria\n"
			con.commit()
			con.close()				
			os.system("cls")



		os.system("cls")
		"""Esta opcion enlista o muestra todos los elementos que esten en la tabla (base de datos en sqlite) """
		con=sqlite3.connect("inventarioElectronica")
		cursor = con.cursor()
		print u"\nLa base de datos se abrió correctamente\n "
		cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA ")
		
		for i in cursor:
			n=0  
			listaElementos.insert(n,"_________________________________________________________________________________________________----")
			n=n+1
			listaElementos.insert(n,"\nID = %s"%(i[0]))
			n=n+1
			listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
			n=n+1
			listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
			n=n+1
			listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
			n=n+1
			listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
			n=n+1
			listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
			n=n+1

		listaElementos.grid(row=1,column=1, columnspan=3)

		#esta funcion me permite contar todos los elementos del la tabla antes mostrada
		cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA")      
		row = cursor.fetchone()
		etiqueta1=Label(ventana3,text="\nHay un total de %s elementos en el inventario\n "%(row[0])).grid(row=3,column=1, columnspan=3) 
		etiqueta1=Label(ventana3,text="Qué elemento desea borrar? ", font="15", fg="blue").grid(row=4,column=1, columnspan=3)

		borrar=StringVar()
		etiqueta5=Label(ventana3,text="\n Digite el ID del elemento que desea Eliminar\n").grid(row=5, column=1)
		buscar1=Entry(ventana3, textvariable=borrar, width=70).grid(row=5, column=2,sticky=W)

		botonBorrar=Button(ventana3,text="Eliminar",width=20,command=eliminar, fg="blue")
		botonBorrar.grid(row=5,column=3,sticky=W) 

		print u"\noperación satisfactoria\n"
		con.commit()
		con.close()
		xscrollbar.config(command=listaElementos.xview)
		yscrollbar.config(command=listaElementos.yview)
		ventana3.transient(root)

#creacion de funcion para llamar un elemento en espescifico de la tabla
	def verUno():		
		ventana3=Toplevel(root)
		ventana3.title("ELiminar Elemento")
		ventana3.geometry("950x650+200+10")
		icono = ventana3.iconbitmap("icono.ico")

		#creacion barra de desplazamiento
		yscrollbar = Scrollbar(ventana3)
		yscrollbar.grid(row=1, column=4,sticky=NS)

		xscrollbar = Scrollbar(ventana3,orient=HORIZONTAL)
		xscrollbar.grid(row=2,column=1, columnspan=4, sticky=NE+NW)
	
	#crear lista
		listaElementos=Listbox(ventana3, width=155, height=30, yscrollcommand=yscrollbar.set, xscrollcommand=xscrollbar.set)
		"""Esta opcion enlista o muestra el elemento que este buscando el usuario, el cual se encuentra
		 en la tabla (base de datos en sqlite) """

		def eliminar():
			listaElementos.delete(0,END)
			con=sqlite3.connect("inventarioElectronica")
			cursor = con.cursor()
			print u"\nLa base de datos se abrió correctamente\n "
			cursor.execute("DELETE FROM INVENTARIO_ELECTRONICA WHERE ID='%s'"%(borrar.get()))
			print u"\nElemento Eliminado con exito, así quedo la nueva tabla\n"	

			tkMessageBox.showinfo("informacion"," Elemento eliminado con exito" )

			cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ELEMENTO='%s'"%(buscar.get()))
			
			for i in cursor:
				n=0  
				listaElementos.insert(n,"_________________________________________________________________________________________________----")
				n=n+1
				listaElementos.insert(n,"\nID = %s"%(i[0]))
				n=n+1
				listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
				n=n+1
				listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
				n=n+1
				listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
				n=n+1
				listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
				n=n+1
				listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
				n=n+1

			listaElementos.grid(row=1,column=1,columnspan=3)

			#esta funcion me permite contar todos los elementos del la tabla antes mostrada
			cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA WHERE ELEMENTO='%s'"%(buscar.get()))      
			row = cursor.fetchone()

			etiqueta1=Label(ventana3,text="\nHay un total de %s elementos en el inventario\n "%(row[0])).grid(row=3,column=1,columnspan=3)

			print u"\noperación satisfactoria\n"
			con.commit()
			con.close()				
			os.system("cls")
		
		con=sqlite3.connect("inventarioElectronica")
		cursor = con.cursor()
		print u"\n La base de datos se abrió correctamente\n "
		cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ELEMENTO='%s'"%(buscar.get()))
		"""la funcion "con.total" cuenta los elementos de la tabla y muestra el numero de elmentos que
		 hay en la pantalla."""
		#print "\n Hay un total de %s elementos en el inventario\n "%(con.total)

		for i in cursor:
			n=0  
			listaElementos.insert(n,"_________________________________________________________________________________________________----")
			n=n+1
			listaElementos.insert(n,"\nID = %s"%(i[0]))
			n=n+1
			listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
			n=n+1
			listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
			n=n+1
			listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
			n=n+1
			listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
			n=n+1
			listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
			n=n+1

		listaElementos.grid(row=1, column=1, columnspan=3)
	#esta funcion me permite contar todos los elementos del la tabla antes mostrada
		cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA")      
		row = cursor.fetchone()
		etiqueta1=Label(ventana3,text="\nHay un total de %s elementos en el inventario\n "%(row[0])).grid(row=3,column=1, columnspan=3) 
		etiqueta1=Label(ventana3,text="Qué elemento desea borrar? ", font="15", fg="blue").grid(row=4,column=1, columnspan=3)

		borrar=StringVar()
		etiqueta5=Label(ventana3,text="\n Digite el ID del elemento que desea Eliminar\n").grid(row=5, column=1)
		buscar1=Entry(ventana3, textvariable=borrar, width=70).grid(row=5, column=2,sticky=W)

		botonBorrar=Button(ventana3,text="Eliminar",width=20,command=eliminar, fg="blue")
		botonBorrar.grid(row=5,column=3,sticky=W) 

		print u"\noperación satisfactoria\n"
		con.commit()
		con.close()

		xscrollbar.config(command=listaElementos.xview)
		yscrollbar.config(command=listaElementos.yview)
		ventana3.transient(root)

	def Salir():
		tkMessageBox.showinfo("informacion"," Cierre la ventana con la X\n en la parte superior\n derecha, gracias" )



# creacion de ventana de opciones
	ventana4=Toplevel(root)
	ventana4.title("Eliminar Elmento")
	ventana4.geometry("500x300+500+200")
	icono = ventana4.iconbitmap("icono.ico")
	etiqueta1=Label(ventana4,text=" Listar Todos los elementos del inventario",font="15").grid(row=1, column=2,sticky=W)
	etiqueta2=Label(ventana4,text=" \n\nListar un elemento en especifico ",font="15").grid(row=2, column=1, columnspan=2)

	etiqueta3=Label(ventana4,text=" ",font="15").grid(row=6, column=2, columnspan=2, sticky=W)

	etiqueta4=Label(ventana4,text=" Salir ",font="15").grid(row=7, column=2,sticky=W)

	buscar=StringVar()
	etiqueta5=Label(ventana4,text="\n IMPORTANTE:DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n", fg="blue").grid(row=3, column=1, columnspan=2)
	etiqueta6=Label(ventana4,text=" Ingrese el NOMBRE del elemento que desea buscar:\n").grid(row=4, column=1, columnspan=2)
	buscar1=Entry(ventana4, textvariable=buscar, width=50).grid(row=5, column=1, columnspan=2)

	botonBuscar=Button(ventana4,text="BUSCAR",width=10,command=verUno, fg="blue")
	botonBuscar.grid(row=5,column=2,sticky=E)
	
	botonTodo=Button(ventana4,text="<O>",width=5,command=verTodo, fg="blue")
	botonTodo.grid(row=1,column=1,sticky=E)

	botonSalir=Button(ventana4,text="<O>", width=5,command=Salir, fg="blue")
	botonSalir.grid(row=7,column=1,sticky=E)

	ventana4.transient(root)

"""Este metodo va a permitir listar o mostrar uno o mas elementos creados en la base de datos(tabla)"""	

def listarElementos ():
	#creacion de funcion para llamar todos los elemento de la tabla
	def listarTodo():
		ventana3=Toplevel(root)
		ventana3.title("Lista de Elementos")
		ventana3.geometry("1000x550+200+30")
		icono = ventana3.iconbitmap("icono.ico")
		#creacion de barras de desplazamiento
		yscrollbar = Scrollbar(ventana3)
		yscrollbar.grid(row=1, column=2,sticky=NS)

		xscrollbar = Scrollbar(ventana3,orient=HORIZONTAL)
		xscrollbar.grid(row=2,column=1, columnspan=2, sticky=NE+NW)



	#crear lista
		listaElementos=Listbox(ventana3, width=163, height=30,yscrollcommand=yscrollbar.set,xscrollcommand=xscrollbar.set)

		os.system("cls")
		"""Esta opcion enlista o muestra todos los elementos que esten en la tabla (base de datos en sqlite) """
		con=sqlite3.connect("inventarioElectronica")
		cursor = con.cursor()
		print u"\nLa base de datos se abrió correctamente\n "
		cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA")
		
		for i in cursor:
			n=0  
			listaElementos.insert(n,"_________________________________________________________________________________________________----")
			n=n+1
			listaElementos.insert(n,"\nID = %s"%(i[0]))
			n=n+1
			listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
			n=n+1
			listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
			n=n+1
			listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
			n=n+1
			listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
			n=n+1
			listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
			n=n+1

		listaElementos.grid(row=1,column=1)

		#esta funcion me permite contar todos los elementos del la tabla antes mostrada
		cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA")      
		row = cursor.fetchone()
		etiqueta1=Label(ventana3,text="\nHay un total de %s elementos en el inventario\n "%(row[0])).grid(row=3,column=1) 	

		print u"\noperación satisfactoria\n"
		con.commit()
		con.close()
		xscrollbar.config(command=listaElementos.xview)
		yscrollbar.config(command=listaElementos.yview)
		ventana3.transient(root)

#creacion de funcion para llamar un elemento en espescifico de la tabla
	def listarUno():		
		ventana3=Toplevel(root)
		ventana3.title("Lista de Elementos")
		ventana3.geometry("1000x550+200+30")
		icono = ventana3.iconbitmap("icono.ico")

		yscrollbar = Scrollbar(ventana3)
		yscrollbar.grid(row=1, column=2,sticky=NS)

		xscrollbar = Scrollbar(ventana3,orient=HORIZONTAL)
		xscrollbar.grid(row=2,column=1, columnspan=2, sticky=NE+NW)
	
	#crear lista
		listaElementos=Listbox(ventana3, width=155, height=30, yscrollcommand=yscrollbar.set, xscrollcommand=xscrollbar.set)
		"""Esta opcion enlista o muestra el elemento que este buscando el usuario, el cual se encuentra
		 en la tabla (base de datos en sqlite) """
		
		con=sqlite3.connect("inventarioElectronica")
		cursor = con.cursor()
		print u"\n La base de datos se abrió correctamente\n "
		cursor.execute("SELECT ID, ELEMENTO, IMAGEN, CARACTERISTICA, DESCRIPCION, UBICACION FROM INVENTARIO_ELECTRONICA WHERE ELEMENTO='%s'"%(buscar.get()))
		"""la funcion "con.total" cuenta los elementos de la tabla y muestra el numero de elmentos que
		 hay en la pantalla."""
		#print "\n Hay un total de %s elementos en el inventario\n "%(con.total)

		for i in cursor:
			n=0  
			listaElementos.insert(n,"_________________________________________________________________________________________________----")
			n=n+1
			listaElementos.insert(n,"\nID = %s"%(i[0]))
			n=n+1
			listaElementos.insert (n,"\nELEMENTO = %s"%(i[1]))
			n=n+1
			listaElementos.insert(n,"\nIMAGEN = %s"%(i[2]))
			n=n+1
			listaElementos.insert(n,"\nCARACTERISTICA = %s"%(i[3]))
			n=n+1
			listaElementos.insert(n,"\nDESCRIPCION = %s"%(i[4]))
			n=n+1
			listaElementos.insert(n,"\nUBICACION= %s"%(i[5]))
			n=n+1

		listaElementos.grid(row=1, column=1)
	#esta funcion me permite contar todos los elementos del la tabla antes mostrada
		cursor.execute("SELECT count(*) FROM INVENTARIO_ELECTRONICA WHERE ELEMENTO='%s'"%(buscar.get()))      
		row = cursor.fetchone()
		etiqueta1=Label(ventana3,text="\nHay un total de %s elementos en el inventario\n "%(row[0])).grid(row=3,column=1) 	

		print u"\noperación satisfactoria\n"
		con.commit()
		con.close()

		xscrollbar.config(command=listaElementos.xview)
		yscrollbar.config(command=listaElementos.yview)
		ventana3.transient(root)

	def Salir():
		tkMessageBox.showinfo("informacion"," Cierre la ventana con la X\n en la parte superior\n derecha, gracias" )



# creacion de ventana de opciones
	ventana4=Toplevel(root)
	ventana4.title("Lista de Elementos")
	ventana4.geometry("500x300+500+200")
	icono = ventana4.iconbitmap("icono.ico")
	etiqueta1=Label(ventana4,text=" Listar Todos los elementos del inventario",font="15").grid(row=1, column=2,sticky=W)
	etiqueta2=Label(ventana4,text=" \n\nListar un elemento en especifico ",font="15").grid(row=2, column=1, columnspan=2)

	etiqueta3=Label(ventana4,text=" ",font="15").grid(row=6, column=2, columnspan=2, sticky=W)

	etiqueta4=Label(ventana4,text=" Salir ",font="15").grid(row=7, column=2,sticky=W)

	buscar=StringVar()
	etiqueta5=Label(ventana4,text="\n IMPORTANTE:DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n", fg="blue").grid(row=3, column=1, columnspan=2)
	etiqueta6=Label(ventana4,text=" Ingrese el NOMBRE del elemento que desea buscar:\n").grid(row=4, column=1, columnspan=2)
	buscar1=Entry(ventana4, textvariable=buscar, width=50).grid(row=5, column=1, columnspan=2)

	botonBuscar=Button(ventana4,text="BUSCAR",width=10,command=listarUno, fg="blue")
	botonBuscar.grid(row=5,column=2,sticky=E)
	
	botonTodo=Button(ventana4,text="<O>",width=5,command=listarTodo, fg="blue")
	botonTodo.grid(row=1,column=1,sticky=E)

	botonSalir=Button(ventana4,text="<O>", width=5,command=Salir, fg="blue")
	botonSalir.grid(row=7,column=1,sticky=E)

	ventana4.transient(root)

		
		
# Aquí terminan las funciones del programa y los metodos a utilizar por el usuario

"""____________________________________________________________________________________________________________________
________________________________________________________________________________________________________________________"""

# Aquí comienzan las funciones y metodos para el funcionamiento de la interfaz gráfica del programa


#Funciones o metodos que se van a llevar acabo para el funcinamiento del programa
	#funcion que permite darle la informacion en la casilla "Acerca de" en el menu de la barra superior 
def informacion():
	tkMessageBox.showinfo("Creado Por","                  Camilo Andres Lopez Sarmiento \n"
							"              Estudiante de Ingenieria electronica\n"
						"Universidad Pedagógica y Tecnológica de Colombia\n"
						"                                 Version 1.0" )

	#funcion que permite salir del programa al oprimir el boton "salir" que se encuentra en el menu de la barra superior en la casilla "Archivo"
def salir():
	quit()

componente=1
def Nuevo():
	global componente
	#Funcion que envia los datos a el metodo agregar de la clase elemento
	def enviarAgregar():
		global componente	
	#comandos en las cuales van a ir las variables que se le van a enviar a la clase elemento
		componente=elemento(nombre.get(),imagen.get(),caracteristica.get(),descripcion.get(),ubicacion.get())
		componente.agregarElemento()
	def cancelar():
		tkMessageBox.showinfo("informacion"," Cierre la ventana con la X\n en la parte superior\n derecha, gracias" )

	#creacion de variables
	nombre=StringVar()
	imagen=StringVar()
	caracteristica=StringVar()
	descripcion=StringVar()
	ubicacion=StringVar()

	ventana2=Toplevel(root)
	ventana2.title("Elemento Nuevo")
	ventana2.geometry("900x300+200+30")
	icono = ventana2.iconbitmap("icono.ico")
	"""creacion del elemento por parte del usuario, aqui se asignan todos los datos necesarios por el usuario 
	que se requieren para la creacion del elemento y se guardan en el metodo "agregarElemento" de la clase 
	"elemento". """

#creacion de etiquetas
	etiqueta1=Label(ventana2,text="\n Complete todos los datos del elemento\n",font="15").grid(row=1, column=1, columnspan=2)
	etiqueta2=Label(ventana2,text="\n IMPORTANTE:DIGITE EL PRIMER CARACTER DEL NOMBRE DEL ELEMENTO EN MAYUSCULA\n",font="15").grid(row=2, column=1, columnspan=2)
	etiqueta3=Label(ventana2,text=" Ingrese el nombre del elemento: ",font="15").grid(row=3, column=1,sticky=W)
	etiqueta4=Label(ventana2,text=" Ingrese la ubicacion de la imagen o foto del elemento: ",font="15").grid(row=4, column=1,sticky=W)
	etiqueta5=Label(ventana2,text=" Ingrese la caracteristica del elemento: ",font="15").grid(row=5, column=1,sticky=W)
	etiqueta6=Label(ventana2,text=" Ingrese la descripcion del elemento: ",font="15").grid(row=6, column=1,sticky=W)
	etiqueta7=Label(ventana2,text=" Ingrese la ubicacion del elemento:\n ",font="15").grid(row=7, column=1,sticky=W)


#creacion de cuadros de texto
	nombre1=Entry(ventana2, textvariable=nombre,width=80).grid(row=3, column=2,sticky=W)
	imagen1=Entry(ventana2, textvariable=imagen,width=80).grid(row=4, column=2,sticky=W)
	caracteristica1=Entry(ventana2, textvariable=caracteristica,width=80).grid(row=5, column=2,sticky=W)
	descripcion1=Entry(ventana2, textvariable=descripcion,width=80).grid(row=6, column=2,sticky=W)
	ubicacion1=Entry(ventana2, textvariable=ubicacion,width=80).grid(row=7, column=2,sticky=NW)

#boton que hace la funcion de pasar los datos de las variables al metodo enviarAgregar
	botonGuardar=Button(ventana2, text="Guardar",width=20,command=enviarAgregar,fg="blue")
	botonGuardar.grid(row=8,column=2)
	botonCancelar=Button(ventana2, text="Cancelar",width=20,command=cancelar,fg="blue")
	botonCancelar.grid(row=8,column=1)

	ventana2.transient(root)

	

#Creacion de la ventada en la cual el usuario va a poder interactuar con el programa
root = Tk()

#titulo de la ventana
root.title('Inventario de elementos Electronicos')

#icono que va a llevar la ventana
icono = root.iconbitmap("icono.ico")

#funcion que nos permite que tan grande quiero que sea la ventana ya sea ancha o alta
root.geometry("1000x550+200+30")

#funcion que nos permite que el usuario NO pueda o SI pueda ampliar la ventana de inicio
root.resizable(width=False, height=False)



#creacion del menu de la barra superior
menubar = Menu(root)
menubar.add_command(label="Acerca de", command=informacion)
menubar.add_command(label="Salir",command=salir)

# etiquetas para darle indicaciones o informacion al usuario
etiqueta1=Label(root,text="INVENTARIO DE ELEMENTOS ELECTRONICOS ", font="CharlemagneStd 30")
etiqueta1.pack()

#widget que nos va a mostrar la barra de la ubicacion del archivo y los contenidos del archivo que se desa ver
menu1=Frame(root)

#funcion que nos permite colocar el widget en la ventana principal y nos perimite utilizar una barra de desplazamiento vertical
menu1.pack(fill=BOTH)

# etiquetas para darle indicaciones o informacion al usuario
etiqueta2=Label(menu1,text="\n IMPORTANTE: Por favor, antes de continuar con el programa, revise si ya tiene creada en su ordenador la tabla del inventario electrónico,\n si no es así por favor cree la tabla y continue con el programa, gracias.\n ",font="15",justify="center")
etiqueta2.grid (row=1,column=1,columnspan=2)
etiqueta3=Label(menu1,text="\n   Crear Tabla del Inventario\n ",font="15",justify="left", fg="blue")
etiqueta3.grid (row=2,column=2,sticky=W)
etiqueta4=Label(menu1,text="\n   Agrear un Elemento\n ",font="15",justify="left")
etiqueta4.grid (row=3,column=2,sticky=W)
etiqueta5=Label(menu1,text="\n   Editar Elementos\n",font="15",justify="left")
etiqueta5.grid (row=4,column=2,sticky=W)
etiqueta6=Label(menu1,text="\n   Eliminar un Elemento\n ",font="15",justify="left")
etiqueta6.grid (row=5,column=2,sticky=W)
etiqueta7=Label(menu1,text="\n   Listar Elementos \n",font="15",justify="left")
etiqueta7.grid (row=6,column=2,sticky=W)
etiqueta8=Label(menu1,text="\n Elija una opción según las instrucciones anteriormente dadas con los botones que aparecen al costado derecho de cada opción \n",font="15",justify="left")
etiqueta8.grid (row=7,column=1,columnspan=2,sticky=W)

# Botnes con los cuales el usuario puede interactuar con las funciones del programa

botonTabla=Button(menu1,text="<O>",width=5,command=crear_Tabla, fg="blue")
botonTabla.grid(row=2,column=1,sticky=E)

botonAgregar=Button(menu1,text="<O>", width=5,command=Nuevo, fg="blue")
botonAgregar.grid(row=3,column=1,sticky=E)

botonEditar=Button(menu1,text="<O>", width=5,command=editarElemento, fg="blue")
botonEditar.grid(row=4,column=1,sticky=E)

botonEliminar=Button(menu1,text="<O>", width=5,command=borrarElemento, fg="blue")
botonEliminar.grid(row=5,column=1,sticky=E)

botonListar=Button(menu1,text="<O>", width=5,command=listarElementos, fg="blue")
botonListar.grid(row=6,column=1,sticky=E)


root.config(menu=menubar)
root.mainloop()




		