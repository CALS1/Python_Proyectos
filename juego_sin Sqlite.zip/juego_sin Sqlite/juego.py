# -*- coding: utf-8 -*-
from random import randint
import os
print "\n"
print "Bienvenido al Juego de Piedra, Papel o Tijera"
print "Elaborado por: CAMILO ANDRÉS LÓPEZ SARMIENTO\n"
print "Reglas del juego: "
print "1. Elige una opción entre Piedra, Papel y Tijera."
print "2. La Piedra le gana a la Tijera.\n  -El Papel le gana a la Piedra.\n  -La Tijera le gana al Papel."
print "3. Si los dos eligen la misma opción es un empate."
print "4. Espera que la máquina o el segundo jugador elija una opción."
print "5. Mira el ganador y tus puntos obtenidos."
print "6. El que tengas más puntos al final del juego GANA"
print "7. Disfruta del juego.\n"
ptsp=0
ptsm=0
empate=0
ptsp1=0
ptsp2=0
empatevs=0

def guardarjm(pe1,pj,pm):
	archivo=open("pe1.txt","w")
	archivo1=open("pm.txt","w")
	archivo2=open("pj.txt","w")
	contenido=archivo.write(pe1)
	contenido1=archivo1.write(pm)
	contenido2=archivo2.write(pj)
	archivo.close()
	archivo1.close()
	archivo2.close()

def guardarjj(pe2,pj1,pj2):
	archivo3=open("pe2.txt","w")
	archivo4=open("pj1.txt","w")
	archivo5=open("pj2.txt","w")
	contenido3=archivo3.write(pe2)
	contenido4=archivo4.write(pj1)
	contenido5=archivo5.write(pj2)
	archivo3.close()
	archivo4.close()
	archivo5.close()

def cargarjm():
	global empate
	global ptsm
	global ptsp
	archivo=open("pe1.txt","r")
	archivo1=open("pm.txt","r")
	archivo2=open("pj.txt","r")
	contenido=archivo.read()
	contenido1=archivo1.read()
	contenido2=archivo2.read()
	archivo.close()
	archivo1.close()
	archivo2.close()
	empate=int(contenido)
	ptsm=int(contenido1)
	ptsp=int(contenido2)

def cargarjj():
	global empatevs
	global ptsp1
	global ptsp2
	archivo3=open("pe2.txt","r")
	archivo4=open("pj1.txt","r")
	archivo5=open("pj2.txt","r")
	contenido3=archivo3.read()
	contenido4=archivo4.read()
	contenido5=archivo5.read()
	archivo3.close()
	archivo4.close()
	archivo5.close()
	empatevs=int(contenido3)
	ptsp1=int(contenido4)
	ptsp2=int(contenido5)

    
def Piedra(player,pc):
	global ptsp
	global ptsm
	global empate
	if pc==1:
		print "Máquina saco Piedra"
		print "Es un Empate, intentalo de nuevo\n"	
		empate+=1
		os.system("pause")
	elif pc==2:
		print "Máquina saco Papel"
		print "Gana la máquina, vuelve a intentarlo\n"	
		ptsm+=1	
		os.system("pause")
	elif pc==3:
		print "Máquina saco Tijera"
		print "Ganaste, felicitaciones\n"
		ptsp+=1	
		os.system("pause")
def Papel(player,pc):
	global ptsm
	global ptsp
	global empate
	if pc==1:
		print "Máquina saco Piedra"
		print "Ganaste, felicitaciones\n"
		ptsp+=1
		os.system("pause")
	elif pc==2:
		print "Máquina saco Papel"
		print "Es un Empate, intentalo de nuevo\n"	
		empate+=1	
		os.system("pause")
	elif pc==3:
		print "Máquina saco Tijera"
		print "Gana la maquina, vuelve a intentarlo\n"
		ptsm+=1
		os.system("pause")
def Tijera(player,pc):
	global ptsp
	global ptsm
	global empate
	if pc==1:
		print "Máquina saco Piedra"
		print "Gana la maquina, vuelve a intentarlo\n "
		ptsm+=1
		os.system("pause")
	elif pc==2:
		print "Máquina saco Papel"
		print "Ganaste, felicitaciones\n"
		ptsp+=1
		os.system("pause")
	elif pc==3:
		print "Máquina saco Tijera"
		print "Es un Empate, intentalo de nuevo\n"
		empate+=1
		os.system("pause")
while True:
	print "\n1. Nuevo Juego\n2. Cargar Partida\n3. Salir\n "
	op=input(" ")
	if op==1:
		print "\nOpciones de juego:\n 1. Contra la máquina\n 2. Contra un amigo\n "
		opcion=input(" ")
		print"\n"
		if opcion==1:
			empate=0
			ptsp=0
			ptsm=0
			guardarjm(str(empate),str(ptsp),str(ptsm))
		
			while True:
				os.system("cls")
				print "PUNTOS --------->  Empatados: "+str(empate)+" | Máquina: "+str(ptsm)+" | Jugador: "+str(ptsp)
				print "\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
				player=input(" ")
				if player==1:
					print "\nEliges Piedra"
					pc=randint(1, 3)
					Piedra(player,pc)
				elif player==2:
					print "\nEliges Papel"
					pc=randint(1, 3)
					Papel(player,pc)
				elif player==3:
					print "\nEliges Tijera"
					pc=randint(1, 3)
					Tijera(player,pc)
				elif player==4:
					print "\n1. Guardar\n2. Guardar y Salir\n3. Salir\n"	
					op1=input(" ")
					if op1==1:
						guardarjm(str(empate),str(ptsp),str(ptsm))
						os.system("cls")
					elif op1==2:
						guardarjm(str(empate),str(ptsp),str(ptsm))
						os.system("cls")
						break
					elif op1==3:
						os.system("cls")
						break
					else:
						print "No es una opción, elige de nuevo"
			  	else:
			    	 print "No es una opción, elige de nuevo"
		elif opcion==2:
			empatevs=0
			ptsp1=0
			ptsp2=0
			guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
			while True:
				os.system("cls")
				print "PUNTOS --------->  Empatados: "+str(empatevs)+" | Jugador 1: "+str(ptsp1)+" | Jugador 2: "+str(ptsp2)			
				print "\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
				player1=input("Jugador1: ")
				os.system("cls")
				print "PUNTOS --------->  Empatados: "+str(empatevs)+" | Jugador 1: "+str(ptsp1)+" | Jugador 2: "+str(ptsp2)			
				print "\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
				player2=input("Jugador2: ")
				jugadas=["Piedra","Papel","Tijera"]
				if player1==1 and player2==1:	
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Es un empate\n"
					empatevs+=1
					os.system("pause")
				elif player1==1 and player2==2:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana Jugador 2\n"
					ptsp2+=1
					os.system("pause")
				elif player1==1 and player2==3:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana Jugador 1\n"
					ptsp1+=1
					os.system("pause")
				elif player1==2 and player2==1:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana Jugador 1\n"
					ptsp1+=1
					os.system("pause")
				elif player1==2 and player2==2:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Es un Empate\n"
					empatevs+=1
					os.system("pause")
				elif player1==2 and player2==3:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana Jugador 2\n"
					ptsp2+=1
					os.system("pause")
				elif player1==3 and player2==1:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana Jugador 2\n"
					ptsp2+=1
					os.system("pause")
				elif player1==3 and player2==2:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana jugador 1\n"
					ptsp1+=1
					os.system("pause")
				elif player1==3 and player2==3:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Es un Empate\n"
					empatevs+=1
					os.system("pause")
				elif player1==4:
					print "\n1. Guardar\n2. Guardar y Salir\n3. Salir\n "	
					op1=input(" ")
					if op1==1:
						guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
						os.system("cls")
					elif op1==2:
						guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
						os.system("cls")
						break
					elif op1==3:
						os.system("cls")
						break
					else:
						print "No es una opción, elige de nuevo"
			  	else:
			    	 print "No es una opción, elige de nuevo"
	elif op==2:
		print "Opciones de juego:\n 1. Contra la máquina\n 2. Contra un amigo\n "
		opcion=input()
		if opcion==1:
			cargarjm()
			while True:
				os.system("cls")
				print "PUNTOS --------->  Empatados: "+str(empate)+" | Máquina: "+str(ptsm)+" | Jugador: "+str(ptsp)
				print "\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
				player=input(" ")
				if player==1:
					print "\nEliges Piedra"
					pc=randint(1, 3)
					Piedra(player,pc)
				elif player==2:
					print "\nEliges Papel"
					pc=randint(1, 3)
					Papel(player,pc)
				elif player==3:
					print "\nEliges Tijera"
					pc=randint(1, 3)
					Tijera(player,pc)
				elif player==4:
					print "\n1. Guardar\n2. Guardar y Salir\n3. Salir\n"	
					op1=input(" ")
					if op1==1:
						guardarjm(str(empate),str(ptsp),str(ptsm))
						os.system("cls")
					elif op1==2:
						guardarjm(str(empate),str(ptsp),str(ptsm))
						os.system("cls")
						break
					elif op1==3:
						os.system("cls")
						break
					else:
						print "No es una opción, elige de nuevo"
			  	else:
			    	 print "No es una opción, elige de nuevo"
		elif opcion==2:
			cargarjj()
			while True:
				os.system("cls")
				print "PUNTOS --------->  Empatados: "+str(empatevs)+" | Jugador 1: "+str(ptsp1)+" | Jugador 2: "+str(ptsp2)			
				print "\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
				player1=input("Jugador1: ")
				os.system("cls")
				print "PUNTOS --------->  Empatados: "+str(empatevs)+" | Jugador 1: "+str(ptsp1)+" | Jugador 2: "+str(ptsp2)			
				print "\nElija una opción:\n 1. Piedra\n 2. Papel\n 3. Tijera\n 4. Salir\n"
				player2=input("Jugador2: ")
				jugadas=["Piedra","Papel","Tijera"]
				if player1==1 and player2==1:	
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Es un empate\n"
					empatevs+=1
					os.system("pause")
				elif player1==1 and player2==2:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana Jugador 2\n"
					ptsp2+=1
					os.system("pause")
				elif player1==1 and player2==3:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana Jugador 1\n"
					ptsp1+=1
					os.system("pause")
				elif player1==2 and player2==1:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana Jugador 1\n"
					ptsp1+=1
					os.system("pause")
				elif player1==2 and player2==2:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Es un Empate\n"
					empatevs+=1
					os.system("pause")
				elif player1==2 and player2==3:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana Jugador 2\n"
					ptsp2+=1
					os.system("pause")
				elif player1==3 and player2==1:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana Jugador 2\n"
					ptsp2+=1
					os.system("pause")
				elif player1==3 and player2==2:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Gana jugador 1\n"
					ptsp1+=1
					os.system("pause")
				elif player1==3 and player2==3:
					print "\n"
					print "Jugador 1 saco "+jugadas[player1-1]+" y Jugador 2 saco "+jugadas[player2-1]
					print "Es un Empate\n"
					empatevs+=1
					os.system("pause")
				elif player1==4:
					print "\n1. Guardar\n2. Guardar y Salir\n3. Salir\n "	
					op1=input(" ")
					if op1==1:
						guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
						os.system("cls")
					elif op1==2:
						guardarjj(str(empatevs),str(ptsp1),str(ptsp2))
						os.system("cls")
						break
					elif op1==3:
						os.system("cls")
						break
					else:
						print "No es una opción, elige de nuevo"
			  	else:
			    	 print "No es una opción, elige de nuevo"
	elif op==3:
		break
	else:
		print "No es una opción, elige denuevo\n"

